<?php
error_reporting(1);

?><?php
$id=$_REQUEST['itemno'];
$itemn=$_REQUEST['usrm'];
include("config.php");
$itemno=$_REQUEST['itemno'];
if(isset($_REQUEST['send']))
  {
	 $mn=$_REQUEST['mn'];
$ban=$_REQUEST['ban'];	 
	   $orderno='so'.rand(1,9999);
	   $sql=mysql_query("insert into booking (society_username,sp_id,bk_dt_execution,bk_confirmation,bk_rating,orderno)
	   values('$itemn','$id','$mn','0','$ban','$orderno')");
	if($sql==false)
	{
		die(mysql_error());
	}
	header("location:new2.php");
  }
if(isset($_REQUEST['log'])=='out')
{
session_destroy();
header("location:index2.php");
}
else if($id=="")
{
header("location:index2.php");
}
if($itemno=="")
{
header("location:index2.php");
}
	
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Society Management</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="form-basic.css">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <style>
  
  .bg-4 { 
      background-color: #2f2f2f; /* Black Gray */
      color: #fff;
	   padding-top: 70px;
      padding-bottom: 70px;
  }

  
  </style>
</head>
<body>
<?php
require 'connect.php';
$bd=$_REQUEST['itemno'];
$bde=$_REQUEST['usrm'];
$sql = "select * from service_provider where sp_id='$bd'";
   $row = $con->query($sql);
   while($arr = $row->fetch_assoc()) 
        {
			$name=$arr['sp_name'];

$ph=$arr['sp_phone_no'];

$area=$arr['sp_area'];
$str=$arr['sp_street'];
$ct=$arr['sp_city'];
$cm=$arr['sp_common_email'];
$add=$str.", ".$area.", ".$ct.". ";

		}

	
	?>
  
	</br>
<div align="center"> <img src="logo1.png" alt="LOGO" width="500" height="100">
</div>
 <div class="container">
	  
  <br/>
	  <hr/>
 <ul class="nav nav-pills">
  
 
    <li><a  href="index.php"><h3>Home</h3></a></li>
		<li class="active"><a href="services.php"><h3>Services</h3></a></li>
		<li><?php echo "<a href='profile.php?itemno=$itemn'>"?><h3>My Profile</h3></a></li>
		<li><a href="aboutus.php"><h3>About Us</h3></a></li>
		<br/>
  </ul>
  <hr/><br/></div>
      <div class="main-content">


        <form method="post" name="f1" onSubmit="return vali()" class="form-basic" action="#">

            <div class="form-title-row">
                <h3>Order Form</h3>
            </div>

            <div class="form-row">
                <label>
                    <span>Name:</span>
                    <input name="uid" type="text" id="uid" onChange="return fnam()" readonly="readonly" value="<?php echo $name;?>">
                </label>
            </div>


            <div class="form-row">
                <label>
                    <span>Address:</span>
                    <input name="uid" type="text" id="uid" onChange="return fnam()" readonly="readonly" value="<?php echo $add;?>">
                </label>
            </div>
			<div class="form-row">
                <label>
                    <span>Phone No:</span>
					<input name="bn" type="text" id="bn"  onChange="return fnam()" readonly="readonly" value="<?php echo $ph;?>">
					</label>
            </div>
			
			<div class="form-row">
                <label>
                    <span>Date Of execution:</span>
                    <input name="mn" type="text" id="mn" required="required" onChange="return phone()">
                </label>
            </div>
			

            <div class="form-row">
                <label>
                    <span>Already had our service? Rate us </span>
                    <select name="ban" id="ban">
                        <option value="1">1</option>
                        <option value="2">2</option>
						<option value="3">3</option>
                        <option value="4">4</option>
						<option value="5">5</option>
                        
                    </select>
                </label>
            </div>
            <div class="form-row">
              <button name="send" type="submit" onclick="gotonextpage()" id="send" value="Send">Submit Form</button>
            </div>

        </form>

    </div>
	
	<script>
		
	 $(document).ready(function(){
    $("#signupBtn").click(function(){
        $("#signupModal").modal();
    });
});
	</script>
</body>  
</html>