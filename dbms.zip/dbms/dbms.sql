-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 07, 2016 at 04:20 PM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbms`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `society_username` text NOT NULL,
  `sp_id` int(3) NOT NULL,
  `bk_dt_execution` varchar(20) NOT NULL,
  `bk_confirmation` tinyint(1) NOT NULL,
  `bk_rating` int(1) NOT NULL,
  `orderno` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`society_username`, `sp_id`, `bk_dt_execution`, `bk_confirmation`, `bk_rating`, `orderno`) VALUES
('krishanshu', 31, '10/5/2016', 1, 5, 'so2109'),
('RaunakPark', 20, '12/06/216', 0, 1, 'so2156'),
('Vasant _Vihar', 31, '5/7/2015', 1, 1, 'so2201'),
('RaunakPark', 41, '13/06/2016', 0, 1, 'so255'),
('RaunakPark', 9, '30/10/2016', 0, 1, 'so34'),
('RaunakPark', 8600, '12/06/2016', 1, 3, 'so3809'),
('Siddhachal', 31, '30/02/2012', 1, 4, 'so454'),
('CosmosHorizon', 31, '15/06/2016', 1, 1, 'so4607'),
('MittalPark', 29, '4/5/2016', 0, 1, 'so5378'),
('RaunakPark', 5203, '23/05/2016', 1, 1, 'so7355'),
('Siddhachal', 12, '5/5/2015', 0, 1, 'so9108'),
('RaunakPark', 31, '15/06/2016', 1, 1, 'so9209'),
('RaunakPark', 28, '30/10/2015', 0, 4, 'so9470'),
('RaunakPark', 16, '12/12/2012', 1, 1, 'so9703');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(10) NOT NULL,
  `category_name` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`) VALUES
(1, 'general maintanance'),
(2, 'hardware'),
(3, 'pest control'),
(4, 'security');

-- --------------------------------------------------------

--
-- Table structure for table `general_maintainance`
--

CREATE TABLE `general_maintainance` (
  `cleaning` varchar(20) NOT NULL,
  `gardening` varchar(20) NOT NULL,
  `gm_lift` varchar(20) NOT NULL,
  `gm_club` varchar(20) NOT NULL,
  `car_wash` varchar(20) NOT NULL,
  `gm_no_emp` varchar(20) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `gm_category_id` int(3) NOT NULL,
  `sp_id` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `general_maintainance`
--

INSERT INTO `general_maintainance` (`cleaning`, `gardening`, `gm_lift`, `gm_club`, `car_wash`, `gm_no_emp`, `start_time`, `end_time`, `gm_category_id`, `sp_id`) VALUES
('no', 'no', 'yes', 'yes', 'yes', '20', '09:00:00', '05:00:00', 1, 1),
('no', 'no', 'yes', 'yes', 'yes', '25', '09:00:00', '05:00:00', 1, 2),
('no', 'yes', 'yes', 'yes', 'no', '30', '09:00:00', '05:00:00', 1, 3),
('yes', 'no', 'no', 'yes', 'yes', '15', '09:00:00', '05:00:00', 1, 4),
('yes', 'no', 'yes', 'yes', 'yes', '10', '09:00:00', '05:00:00', 1, 5),
('yes', 'no', 'yes', 'yes', 'yes', '30', '09:00:00', '05:00:00', 1, 6),
('yes', 'yes', 'no', 'yes', 'yes', '20', '09:00:00', '05:00:00', 1, 7),
('yes', 'yes', 'no', 'yes', 'yes', '20', '09:00:00', '05:00:00', 1, 8),
('yes', 'yes', 'no', 'yes', 'yes', '30', '09:00:00', '05:00:00', 1, 9),
('yes', 'yes', 'yes', 'no', 'yes', '25', '09:00:00', '05:00:00', 1, 10),
('yes', 'yes', 'yes', 'yes', 'no', '25', '09:00:00', '05:00:00', 1, 11),
('yes', 'yes', 'yes', 'yes', 'no', '30', '09:00:00', '05:00:00', 1, 12),
('yes', 'yes', 'yes', 'yes', 'yes', '20', '09:00:00', '05:00:00', 1, 13),
('yes', 'yes', 'yes', 'yes', 'yes', '30', '09:00:00', '05:00:00', 1, 14);

-- --------------------------------------------------------

--
-- Table structure for table `hardware`
--

CREATE TABLE `hardware` (
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `hd_plumbing` varchar(20) NOT NULL,
  `hd_electric_work` varchar(20) NOT NULL,
  `hd_wood_work` varchar(20) NOT NULL,
  `hd_glass_work` varchar(20) NOT NULL,
  `hd_masonary` varchar(20) NOT NULL,
  `hd_painters` varchar(20) NOT NULL,
  `hd_category_id` int(3) NOT NULL,
  `sp_id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hardware`
--

INSERT INTO `hardware` (`start_time`, `end_time`, `hd_plumbing`, `hd_electric_work`, `hd_wood_work`, `hd_glass_work`, `hd_masonary`, `hd_painters`, `hd_category_id`, `sp_id`) VALUES
('09:00:00', '17:00:00', 'yes', 'yes', 'yes', 'no', 'no', 'yes', 2, 40),
('10:00:00', '18:00:00', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 2, 41),
('12:00:00', '17:00:00', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 2, 42),
('11:00:00', '18:00:00', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 2, 43),
('09:00:00', '19:00:00', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', 2, 44),
('10:00:00', '16:00:00', 'no', 'yes', 'yes', 'yes', 'yes', 'no', 2, 45),
('12:00:00', '19:00:00', 'no', 'no', 'yes', 'yes', 'yes', 'yes', 2, 46),
('09:00:00', '17:00:00', 'no', 'yes', 'no', 'yes', 'no', 'yes', 2, 5203),
('10:00:00', '15:00:00', 'no', 'no', 'no', 'no', 'no', 'no', 2, 8600);

-- --------------------------------------------------------

--
-- Table structure for table `pest_control`
--

CREATE TABLE `pest_control` (
  `pc_hrf` time NOT NULL,
  `pc_commercial` varchar(20) NOT NULL,
  `house_flies` varchar(20) NOT NULL,
  `ant` varchar(20) NOT NULL,
  `termites` varchar(20) NOT NULL,
  `rat` varchar(20) NOT NULL,
  `spider` varchar(20) NOT NULL,
  `spray` varchar(20) NOT NULL,
  `fog` varchar(20) NOT NULL,
  `pc_category_id` int(3) NOT NULL,
  `pc_hrt` time NOT NULL,
  `sp_id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pest_control`
--

INSERT INTO `pest_control` (`pc_hrf`, `pc_commercial`, `house_flies`, `ant`, `termites`, `rat`, `spider`, `spray`, `fog`, `pc_category_id`, `pc_hrt`, `sp_id`) VALUES
('09:00:00', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'yes', 3, '17:00:00', 30),
('10:00:00', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'yes', 3, '18:00:00', 31),
('12:00:00', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'yes', 3, '17:00:00', 32),
('11:00:00', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 3, '18:00:00', 33),
('09:00:00', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'yes', 3, '19:00:00', 34),
('10:00:00', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'yes', 3, '16:00:00', 35),
('12:00:00', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 3, '19:00:00', 36),
('11:00:00', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 3, '18:00:00', 37),
('09:00:00', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'yes', 3, '19:00:00', 38),
('10:00:00', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 3, '16:00:00', 39);

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `regid` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`regid`, `username`, `password`, `type`) VALUES
(1, 'RaunakPark', '454', '1'),
(2, 'CosmosHorizon', '545', '1'),
(3, 'Siddhachal', 'dfds', '1'),
(4, 'Vasant _Vihar', 'gd', '1'),
(5, 'Lok Puram', 'gs', '1'),
(6, 'Gawand _baug', 'dgsdg', '1'),
(7, 'LokUpvan', 'fg', '1'),
(8, 'DevdayaNagar', 'dgfs', '1'),
(9, 'MittalPark', 'fdg', '1'),
(10, 'Raheja_gardens', 'dfg', '1'),
(11, 'HiranandaniMedows', 'sfg', '1'),
(12, 'HiranandaniEstate', 'sfg', '1'),
(13, 'Prakruti', 'gsd', '1'),
(14, 'Varsha', 'gsd', '1'),
(15, 'Sai _Krupa', 'gsd', '1'),
(16, 'RohideshwarDarshan', 'sd', '1'),
(17, 'VidharbhaVikas ', 'g', '1'),
(18, 'Mastermind', 'sd', '1'),
(19, 'SubodhSakhari', 'sdg', '1'),
(20, 'Evershin_ Halley_Towres ', 'sdg', '1'),
(21, 'Vastu_Heights', 'sd', '1'),
(22, 'MahindraGardens', 'gsd', '1'),
(23, 'Shanti_Industrial', 'gsd', '1'),
(24, 'Green_Ridge ', 'gs', '1'),
(25, 'Cosmopolitan', 'dg', '1'),
(26, 'Omkar', 'sdg', '1'),
(27, 'Shrenik', 'sg', '1'),
(28, 'Prathamesh', 'sg', '1'),
(29, 'ultraPestConotrol', 'sg', '2'),
(30, 'star123', 'sss', '2'),
(31, 'panama14', 'gs', '2'),
(32, 'best45', 'ddv', '2'),
(33, 'eagle44', 'dvfdh', '2'),
(34, 'newindia1', 'fgjfhj', '2'),
(35, 'palwe54', 'gdfh', '2'),
(36, 'rishan87', 'hdj', '2'),
(37, 'organic13', 'shdhdf', '2'),
(38, 'superstar', 'hdj', '2'),
(39, 'maharsahtr', 'hdf', '2'),
(40, 'hariom', 'hd', '2'),
(41, 'mahakali', 'h', '2'),
(42, 'omkarsdf', 'jh', '2'),
(43, 'starsnnc', 'hdjs', '2'),
(44, 'patel454', 'hddj', '2'),
(45, 'mumbaimerijaan', 'shdhdf', '2'),
(46, 'coolkaus', '123456', '2'),
(57, 'aniket123', '456', '2'),
(58, 'kamalkakhan', '4656', '2'),
(59, 'chauhan0124', '899', '2'),
(60, 'saifshaikh12', 'ggh', '2'),
(61, 'nagesh14', 'jkj', '2'),
(62, 'umeah44', 'fbb', '2'),
(63, 'sanket77', 'fff', '2'),
(64, 'yash7', 'rrr', '2'),
(65, 'pandurang14', '14', '2'),
(66, 'kailash11', 'yyy', '2'),
(67, 'kirit147', '222', '2'),
(68, 'satish44', '454', '2'),
(69, 'pravina14', 'kn', '2'),
(70, 'anil25', 'asa', '2'),
(71, 'ravi12', '121', '2'),
(72, 'mulemahesh', '445', '2'),
(73, 'akash96', 'jkj', '2'),
(74, 'vishal05', '444', '2'),
(75, 'raiak', '222', '2'),
(76, 'pilleakshay', '444', '2'),
(77, 'sudhanshu', '333', '2'),
(78, 'balajiv', 'vvv', '2'),
(79, 'patilram', '888', '2'),
(80, 'sumitkadam01', 'hgg', '2'),
(81, 'prgautam', '222', '2'),
(82, 'ajmalk', '111', '2'),
(83, 'pramodthakur', '88', '2'),
(84, 'sharmashivam', 'gh', '2'),
(85, 'vinitgiri', '456', '2'),
(87, 'krishanshu', '1234', '1'),
(88, 'vasisht', '123456', '1'),
(89, 'swaphops', '1230', '2');

-- --------------------------------------------------------

--
-- Table structure for table `security`
--

CREATE TABLE `security` (
  `s_avai_staff` int(4) NOT NULL,
  `age_min` int(2) NOT NULL,
  `age_max` int(11) NOT NULL,
  `s_certification` varchar(20) NOT NULL,
  `s_category_id` int(11) NOT NULL,
  `sp_id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `security`
--

INSERT INTO `security` (`s_avai_staff`, `age_min`, `age_max`, `s_certification`, `s_category_id`, `sp_id`) VALUES
(10, 20, 37, 'A', 4, 15),
(14, 25, 36, 'B', 4, 16),
(23, 21, 40, 'C', 4, 17),
(15, 21, 45, 'D', 4, 18),
(10, 23, 46, 'D', 4, 19),
(9, 24, 45, 'B', 4, 20),
(5, 30, 45, 'A', 4, 21),
(16, 26, 40, 'D', 4, 22),
(22, 26, 36, 'A', 4, 23),
(27, 25, 36, 'A', 4, 24),
(12, 27, 45, 'B', 4, 25),
(11, 23, 50, 'B', 4, 26),
(18, 21, 51, 'C', 4, 27),
(17, 20, 45, 'D', 4, 28),
(16, 25, 50, 'A', 4, 29);

-- --------------------------------------------------------

--
-- Table structure for table `service_provider`
--

CREATE TABLE `service_provider` (
  `sp_id` int(10) NOT NULL,
  `sp_name` varchar(50) NOT NULL,
  `sp_phone_no` varchar(10) NOT NULL,
  `sp_mf_name` varchar(50) NOT NULL,
  `sp_ml_name` varchar(50) NOT NULL,
  `sp_area` varchar(50) NOT NULL,
  `sp_street` varchar(50) NOT NULL,
  `sp_city` varchar(50) NOT NULL,
  `sp_common_email` varchar(50) NOT NULL,
  `sp_category_id` varchar(20) NOT NULL,
  `sp_username` varchar(50) NOT NULL,
  `sp_pincode` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `service_provider`
--

INSERT INTO `service_provider` (`sp_id`, `sp_name`, `sp_phone_no`, `sp_mf_name`, `sp_ml_name`, `sp_area`, `sp_street`, `sp_city`, `sp_common_email`, `sp_category_id`, `sp_username`, `sp_pincode`) VALUES
(1, 'suvidha maintainance', '9699134365', 'aniket', 'jain', 'kanjurmarg road', ' savita devi mandir', 'mumbai', 'aniketjain@yahoo.com', '1', 'aniket123', '400005'),
(2, 'kamal khan services', '9699134456', 'kamaal ', 'khan', 'mulund', 'near darga, opposite sneha book depot', 'mumbai', 'kamalkhan@gmail.com', '1', 'kamalkakhan', '400006'),
(3, 'complete maintainance', '9613515458', 'vishal', 'chauhan', 'bandra west', 'nathhuji road', 'mumbai', 'vishalchauhan@yahoo.com', '1', 'chauhan0124', '400021'),
(4, 'pro safaai services', '7588228324', 'saifuddin ', 'shaikh', 'santa cruz', 'gandhi road', 'mumbai', 'saifshaikh@gmail.com', '1', 'saifshaikh12', '400025'),
(5, 'nagesh maintanance', '9422159949', 'nagesh ', 'shekokar', 'mashid', 'opposite aarti apartment', 'mumbai', 'nagesh1414@yahoo.com', '1', 'nagesh14', '400035'),
(6, 'clean it services', '9425112522', 'umesh', 'badgujar', 'neral', 'saint mary road', 'mumbai', 'umeanbadgujar@gmail.com', '1', 'umeah44', '400008'),
(7, 'clean jobs', '7894561298', 'sanket', 'sarda', 'badlapur', 'shekokar marg', 'mumbai', 'sanketsarda77@gmail.com', '1', 'sanket77', '400007'),
(8, 'lakshminarayan  services', '8652342208', 'yash', 'parekh', 'dadar', 'palav marg', 'mumbai', 'yashparekh007@gmail.com', '1', 'yash7', '400007'),
(9, 'dial4cleanliness', '9890305228', 'pandurang', 'bugad', 'dadar', 'bhadrakali road', 'mumbai', 'pandurangbugad@gmail.com', '1', 'pandurang11', '400012'),
(10, 'timesarvez', '9893124224', 'kailash', 'dangi', 'matunga', 'vidyaaniketan colony', 'mumbai', 'kailashdangi11@gmail.com', '1', 'kailash11', '400023'),
(11, 'cleansweep', '022 24510 ', 'kirit', 'shah', 'andheri east', 'court road', 'mumbai', 'kiritshah10@gmail.com', '1', 'kirit147', '400019'),
(12, 'germi clean services', '022 5124 2', 'satish', 'bakde', 'panvel', 'hutatma road', 'mumbai', 'satishbakde@gail.com', '1', 'satish44', '400001'),
(13, 'tulips cleaning', '022 3568 1', 'pravina', 'shubhade', 'churchgate', 'sea link road', 'mumbai', 'pravinashubhade@yahoo.com', '1', 'pravina14', '400008'),
(14, 'all maintainance', '022 4021 8', 'anil', 'choudhary', 'churni  road', 'sripad nagar', 'mumbai', 'anilchoudhari@gmail.com', '1', 'anil25', '400001'),
(15, 'Trig Agencies', '9832211222', 'Ravishankar ', 'Malhotra', 'BALLAD ESTATE', 'Chatrapati Shivaji Marg', 'mumbai', 'trigagencies@gmail.com', '4', 'ravi12', '400008'),
(16, 'GROUP 7 GUARDS', '9562432533', 'MAHESH ', 'mule', 'BHANDUP', 'Sane Guruji Marg', 'mumbai', 'group7guards@hotmail.com', '4', 'mulemahesh', '400019'),
(17, 'MONARG SECURITY', '9853452355', 'AKASH', 'CHOPE', 'CHINCH BANDAR', 'Bombay Samachar Marg', 'mumbai', 'monargsecurity@gmail.com', '4', 'akash96', '400005'),
(18, 'LISA SECURITY', '8865432156', 'VISHAL', 'KHOPKAR', 'EAST DADAR', 'Jaiprakash Marg', 'mumbai', 'lisasecurity@gmail.com', '4', 'vishal05', '400003'),
(19, 'VIGILANTE SECURITY', '2228784880', 'TUSHAR ', 'RAI', 'KOLABA BRIDGE', 'veer Manekar Marg', 'mumbai', 'vigilantesesurity@gmail.com', '4', 'raiak', '400007'),
(20, 'TOPS GROUP', '8620025432', 'AKSHAY', 'PILLE', 'CHURCHGATE', 'Nagar Chauk', 'mumbai', 'topsgroup@rediffmail.com', '4', 'pilleakshay', '400005'),
(21, 'GEETE SECURITY', '9699163215', 'SUDHANSHU', 'CHAUHAN', 'DONGRI', 'Lokmanya Tilak Marg', 'mumbai', 'geetesecurity@gmail.com', '4', 'sudhanshu', '400007'),
(22, 'SURAKSHA VIP SECURITY', '2226106881', 'BALAJI', 'VAIDYA', 'FLORA FOUNTAIN', 'Mahapalika Marg', 'mumbai', 'surakshavipsecurity@gmail.com', '4', 'balajiv', '400005'),
(23, 'SAFE SECURITY', '8080545624', 'RAM', 'PATIL', 'GRANT ROAD', 'N M Marg', 'mumbai', 'safesecurity@gmail.com', '4', 'patilram', '400003'),
(24, 'EAGLE SECURITY', '2365635656', 'SUMIT ', 'KADAM', 'JECOB CIRCLE', 'Hutatma Chauk', 'mumbai', 'eaglesecurity@gmail.com', '4', 'sumitkadam01', '400019'),
(25, 'G4 SECURITY', '8965864566', 'PRASHIK', 'GAUTHAM', 'KALA GHODA', 'Valchand Hirachand Road', 'mumbai', 'g4security@gmail.com', '4', 'prgautam', '400005'),
(26, 'FLASH SECURITY', '8965556356', 'AJMAL ', 'KHAN', 'MANTRALAYA', 'August Kranti Marg', 'mumbai', 'flashsecurity@hotmail.com', '4', 'ajmalk', '400012'),
(27, 'SAKSHAM  SECURITY', '8955565225', 'PRAMOD', 'THAKUR', 'PRABHADEVI ROAD', 'Dr Deshmukh Road', 'mumbai', 'sakshamsecurity@gmail.com', '4', 'pramodthakur', '400011'),
(28, 'FLAG SECURITY', '9989585656', 'SHIVAM', 'SHARMA', 'SAKINAKA', 'S V Patel Marg', 'mumbai', 'flagsecurity@gmail.com', '4', 'sharmashivam', '400019'),
(29, 'HUNTER SECURITY FORCE', '2310255325', 'VINIT ', 'GIRI', 'SAHAR', 'M Lakshmibai Chauk', 'mumbai', 'huntersecurityforce@rediffmail.com', '4', 'vinitgiri', '400002'),
(30, 'Ultra Pest Control', '022-217321', 'Manooj', 'Shettyes', 'Regal Plaza', 'Lok Puram', 'Thane', 'topsgroup@rediffmail.com', '3', 'ultraPestConotrol', '400008'),
(31, 'Star One Pest Control Services', '022-385687', 'abhishekh', 'kabade', 'Mahadev Bagal Chawl', 'Service Road', 'Thane', 'geetesecurity@gmail.com', '3', 'star123', '400007'),
(32, 'Panoama Pest control', '022-230916', 'kaustubh', 'dangi', 'noajeevano Societyes', 'Laminogtono Road', 'Mumbai Central', 'yashparekh007@gmail.com', '3', 'panama14', '400007'),
(33, 'The Pest Control Companoyes', '022-392551', 'sahil', ' khan', 'Prathmesh Park', 'Veera Desai Road', 'Andheri West', 'pandurangbugad@gmail.com', '3', 'best45', '400012'),
(34, 'Eagle Pesticide', '9833622270', 'amar', 'singh', 'Shop noo 5 Parvati Krupa', 'next to apna bazaar', 'Andheri West', 'eagles@gmail.com', '3', 'eagle44', '400023'),
(35, 'new India Pest Control', '9820099701', 'avinash', 'shelke', 'C2-1-3-3', 'Sector-16', 'Vashi', 'hunterforce@rediffmail.com', '3', 'newindia1', '400019'),
(36, 'Palwe Pest Control', '9423175737', 'manoj', 'palwe', 'Jayesanot Oil Mill Complex', 'Plot noo 48 49,Sector noo19a', 'Vashi', 'kiritshah10@gmail.com', '3', 'palwe54', '400001'),
(37, 'Rishaano Pest Control', '9819065064', 'avinash', ' shetty', 'Kailash Esplanoade', 'LBS Road', 'Ghatkopar', 'satishbakde@gail.com', '3', 'rishan87', '400008'),
(38, 'Organic Pest Control', '022-385461', 'rakesh', 'pujari', 'Kajupada', 'RGS road', 'Borivali East', 'pravinashubhade@yahoo.com', '3', 'organic13', '400001'),
(39, 'Super Star Pest Control Services', '9029235443', 'mikesh', 'jain', 'nol-1/A-18/4', 'Sector 10', 'nerul', 'anilchoudhari@gmail.com', '3', 'superstar', '400008'),
(40, 'Maharashtra Hardware', '9605068879', 'vyankatesh', 'band', 'navjeevan Societies', 'Lamington Road', 'Bandra', 'trigagencies@gmail.com', '2', 'maharsahtr', '400019'),
(41, 'Hari Om Hardware', '7945500669', 'om', 'chaudhary', 'Kailash Esplanoade', 'LBS Road', 'Ghatkopar East', 'group7guards@hotmail.com', '2', 'hariom', '400005'),
(42, ' Mahakali Hardware', '7290807069', 'aniket ', 'naktode', 'Sakinoaka', 'Linok road', 'Andheri West', 'aniketjain@yahoo.com', '2', 'mahakali', '400003'),
(43, 'Omkar Hardware services', '8950413210', 'shailesh', 'jain', 'Ashok nagar', 'Jno Road', 'Mulund', 'kamalkhan@gmail.com', '2', 'omkarsdf', '400007'),
(44, 'Star Plumbing', '8840513410', 'pravin', 'malpani', 'Shivai nagar', 'noB Road', 'Bhandup', 'vishalchauhan@yahoo.com', '2', 'starsnnc', '400005'),
(45, 'Patel Hardware', '9045893409', 'ashish', 'patel', 'C12-23', 'Sector 11', 'Sanopada', 'saifshaikh@gmail.com', '2', 'patel454', '400007'),
(46, 'Mumbai Hardware', '022-215432', 'suyog', 'bangad', 'Shop no. 32', 'Sector 15', 'Vashi', 'nagesh1414@yahoo.com', '2', 'mumbaimerijaan', '400005'),
(5203, 'Redcherry', '9896134365', 'kaustubh', 'pande', 'Gandhi Nagar', 'Khau Galli', 'Mumbai', 'swaroop@h.com', '2', 'swaphops', '400013'),
(8600, 'Bhagnani Brothers', '9699134362', 'kaustubh', 'kukreja', '32/45, vidyavihar chawl', 'chawalmandi road', 'matunga', 'coolkaustubh@gmail.com', '2', 'coolkaus', '400019');

-- --------------------------------------------------------

--
-- Table structure for table `society_details`
--

CREATE TABLE `society_details` (
  `society_id` int(10) NOT NULL,
  `society_name` text NOT NULL,
  `phone_no` int(10) NOT NULL,
  `area_name` text NOT NULL,
  `street_name` text NOT NULL,
  `city` text NOT NULL,
  `society_email` varchar(30) NOT NULL,
  `bldg_nos` int(2) NOT NULL,
  `floor_nos` int(2) NOT NULL,
  `flat_per_floor` int(2) NOT NULL,
  `lifts_no` int(2) NOT NULL,
  `society_area` float NOT NULL,
  `estd_date` date NOT NULL,
  `username` text NOT NULL,
  `society_pincode` int(6) NOT NULL,
  `manager_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `society_details`
--

INSERT INTO `society_details` (`society_id`, `society_name`, `phone_no`, `area_name`, `street_name`, `city`, `society_email`, `bldg_nos`, `floor_nos`, `flat_per_floor`, `lifts_no`, `society_area`, `estd_date`, `username`, `society_pincode`, `manager_id`) VALUES
(301, 'Raunak park', 2147483647, 'koknipada', 'pokhran road number 2', 'Thane (W)', '', 0, 22, 7, 4, 1, '0000-00-00', 'RaunakPark', 400019, 11),
(302, 'Cosmos Horizon', 2147483647, 'koknipada', 'pokhran road number 2', 'Thane (W)', '', 0, 3, 27, 4, 3, '0000-00-00', 'CosmosHorizon', 400008, 12),
(303, 'Siddhachal', 2147483647, 'Vasant Vihar', 'pokhran road number 2', 'Thane (W)', '', 0, 23, 7, 4, 1, '0000-00-00', 'Siddhachal', 400007, 13),
(304, 'Vasant Vihar', 2147483647, 'Vasant Vihar', 'pokhran road number 2', 'Thane (W)', '', 0, 99, 7, 4, 1, '0000-00-00', 'Vasant _Vihar', 400007, 14),
(305, 'Lok Puram', 2147483647, 'Vasant Vihar', 'pokhran road number 2', 'Thane (W)', '', 0, 15, 7, 4, 1, '0000-00-00', 'Lok Puram', 400012, 15),
(306, 'Gawand baug', 2147483647, 'koknipada', 'pokhran road number 2', 'Thane (W)', '', 0, 12, 12, 4, 2, '0000-00-00', 'Gawand _baug', 400023, 16),
(307, 'Lok Upvan', 2147483647, 'Vasant Vihar', 'pokhran road number 2', 'Thane (W)', '', 0, 11, 7, 4, 1, '0000-00-00', 'LokUpvan', 400019, 17),
(308, 'Devdaya Nagar', 2147483647, 'Shivai Nagar', 'pokhran road number 1', 'Thane (W)', '', 0, 14, 4, 2, 0, '0000-00-00', 'DevdayaNagar', 400001, 18),
(309, 'Mittal Park', 2147483647, 'Teen Hath naka', 'Eastern Express Highway', 'Thane (W)', '', 0, 3, 14, 4, 2, '0000-00-00', 'MittalPark', 400008, 19),
(310, 'Raheja gardens', 2147483647, 'Teen Hath naka', 'Eastern Express Highway', 'Thane (W)', '', 0, 8, 23, 4, 3, '0000-00-00', 'Raheja_gardens', 400001, 20),
(311, 'Hiranandani Medows', 2147483647, 'Pawar Nagar', 'Glady Alwaryes Road', 'Thane (W)', '', 0, 12, 23, 4, 3, '0000-00-00', 'HiranandaniMedows', 400008, 21),
(312, 'Hiranandani Estate', 2147483647, 'Patlipada', 'GB Road', 'Thane (W)', '', 0, 22, 16, 4, 2, '0000-00-00', 'HiranandaniEstate', 400019, 22),
(313, 'Prakruti', 2147483647, 'Teen Hath naka', 'Eastern Express Highway', 'Thane (W)', '', 0, 2, 7, 4, 1, '0000-00-00', 'Prakruti', 400005, 23),
(314, 'Varsha', 2147483647, 'Teen Hath naka', 'Eastern Express Highway', 'Thane (W)', '', 0, 2, 7, 3, 1, '0000-00-00', 'Varsha', 400003, 24),
(315, 'Sai Krupa', 2147483647, 'Teen Hath naka', 'Eastern Express Highway', 'Thane (W)', '', 0, 1, 4, 3, 0, '0000-00-00', 'Sai _Krupa', 400007, 25),
(316, 'Rohideshwar Darshan', 2147483647, '', '', 'Dombivali', '', 0, 4, 12, 4, 2, '0000-00-00', 'RohideshwarDarshan', 400005, 26),
(317, 'Vidharbha Vikas Co - Operative Society Limited', 2147483647, 'Hanuman Nagar', '', 'Kandivali (E)', '', 0, 4, 12, 5, 2, '0000-00-00', 'VidharbhaVikas ', 400007, 27),
(318, 'Mastermind Iv Premises Co - Op Society', 2147483647, 'Aareymilkcol', 'Royal Palms', 'Andheri', '', 0, 12, 11, 4, 2, '0000-00-00', 'Mastermind', 400005, 28),
(319, 'Subodh Sakhari Patsanstha Limited', 2147483647, 'Barve Nagar', '', 'Barve Nagar', '', 0, 11, 7, 4, 1, '0000-00-00', 'SubodhSakhari', 400003, 29),
(320, 'Evershine Halley Towres Chs Limited', 2147483647, 'Lobby Emp 47', 'Thakur Village', 'Kandivali (E)', '', 0, 6, 7, 4, 1, '0000-00-00', 'Evershin_ Halley_Towres ', 400019, 30),
(321, 'Vastu Heights Chs', 2147483647, 'Sundervan Complex', '', 'Andheri West', '', 0, 9, 4, 5, 0, '0000-00-00', 'Vastu_Heights', 400005, 31),
(322, 'Mahindra Gardens Orchid Chs Limited', 2147483647, 'B - 1 Mahindra Garden', 'S Vivekanand R', 'Goregaon (W)', '', 0, 16, 5, 5, 0, '0000-00-00', 'MahindraGardens', 400012, 32),
(323, 'Shanti Industrial Premises', 2147483647, 'Shanti Indu Estate', 'R Prasad Road', 'Mulund (W)', '', 0, 12, 12, 4, 2, '0000-00-00', 'Shanti_Industrial', 400011, 33),
(324, 'Green Ridge Tower Chs Limited', 2147483647, 'Chikuwadi', 'Link Road', 'Borivali (W)', '', 0, 17, 16, 4, 2, '0000-00-00', 'Green_Ridge ', 400019, 34),
(325, 'Cosmopolitan Chs Limited', 2147483647, 'Govt Rest House Building', 'Plot 2902', 'Panvel+D2F27:G27', '', 0, 14, 16, 4, 2, '0000-00-00', 'Cosmopolitan', 400002, 35),
(326, 'Omkar CHSL', 2147483647, 'Mahakali Nagar', '', 'Mulund (E)', '', 0, 2, 5, 4, 0, '0000-00-00', 'Omkar', 400007, 36),
(327, 'New Shrenik', 2147483647, 'Ashok Nagar', '', 'Mulund(W)', '', 0, 11, 3, 4, 0, '0000-00-00', 'Shrenik', 400002, 37),
(328, 'Prathamesh Co-op Housing Society', 2147483647, 'Abhyudaya Nagar', 'Kalachowki', 'Cotton Green', '', 0, 23, 4, 5, 0, '0000-00-00', 'Prathamesh', 400008, 38),
(330, 'gokuldham ', 123456789, 'wadala', 'patel road', 'mumbai', 'srb12031996@gmail.com', 1, 10, 5, 2, 110, '2016-05-11', 'krishanshu', 400012, 357),
(331, 'Ridhi Sidhhi Complex', 2147483647, 'dombivali', 'gandhi road', 'mumbai', 'v@g.com', 5, 6, 6, 6, 110, '2016-05-19', 'vasisht', 400012, 649);

-- --------------------------------------------------------

--
-- Table structure for table `society_manager`
--

CREATE TABLE `society_manager` (
  `manager_id` int(10) NOT NULL,
  `mf_name` varchar(50) NOT NULL,
  `ml_name` varchar(50) NOT NULL,
  `sm_email_id` varchar(50) NOT NULL,
  `sm_phone_no` int(10) NOT NULL,
  `sm_flat_no` varchar(50) NOT NULL,
  `sm_bldg_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `society_manager`
--

INSERT INTO `society_manager` (`manager_id`, `mf_name`, `ml_name`, `sm_email_id`, `sm_phone_no`, `sm_flat_no`, `sm_bldg_name`) VALUES
(11, 'Milind', 'Karve', 'milnd.karve@gmail.com', 2147483647, '3A', 'Skyline'),
(12, 'Narendra ', 'Kulkarni', 'nhkulkarni@gmail.com', 2147483647, '202', '21'),
(13, 'Satish', 'Rane', 'satishrane78@gmail.com', 2147483647, '401', '54'),
(14, 'Rahul ', 'Yadav', 'rahulyadav@gmail.com', 2147483647, '302', 'A'),
(15, 'Omprakash', 'jain', 'omprakash@gmail.com', 2147483647, '323', '11'),
(16, 'Manish', 'Jain', 'manishjain@gmail.com', 2147483647, '603', '4'),
(17, 'Sagar', 'Pathak', 'sagarpathak@gmail.com', 2147483647, '502', '3'),
(18, 'Rahul ', 'Kelkar', 'rahulkelkar@gmail.com', 2147483647, '201', '6'),
(19, 'Girish', 'Joshi', 'girishjoshi@gmail.com', 2147483647, '202', '2'),
(20, 'Mohan', 'Tiwari', 'manojtiwari@gmail.com', 2147483647, '304', 'E'),
(21, 'Kushal', 'Pandey', 'kushalpandey@gmail.com', 2147483647, '304', 'Nilgiri'),
(22, 'Arvind', 'Deshpande', 'arvinddeshpande@gmail.com', 2147483647, '501', 'Sapphire'),
(23, 'Shirish', 'Karnik', 'shirishkarnik@gmail.com', 2147483647, '203', 'F'),
(24, 'Mahesh', 'Rane', 'maheshrane@gmail.com', 2147483647, '603', 'Twilight'),
(25, 'Rohit', 'Khopkar', 'rohitkhopkar@gmail.com', 2147483647, '125', 'Ashoka'),
(26, 'Nitin', 'Shetty', 'nitinshetty@gmail.com', 2147483647, '503', 'D'),
(27, 'Varun', 'Patil', 'varunpatil@gmail.com', 2147483647, '204', 'J'),
(28, 'Abhishek', 'Patil', 'abhishekpatil@gmail.com', 2147483647, '125', '2'),
(29, 'Atharva', 'Singh', 'atharvasingh@gmail.com', 2147483647, '215', '3'),
(30, 'Prasad', 'Joshi', 'prasadjoshi@gmail.com', 2147483647, '255', '2'),
(31, 'Harish', 'Singh', 'harishsingh@gmail.com', 2147483647, '214', 'A'),
(32, 'Mohammad', 'Akram', 'mohammadakram@gmail.com', 2147483647, '254', 'A'),
(33, 'Jatin', 'Sapru', 'jatinsapru@gmail.com', 2147483647, '602', '6'),
(34, 'Saurabh', 'Shah', 'saurabhshah@gmail.com', 2147483647, '701', '4'),
(35, 'Vivekanad', 'Pathak', '', 2147483647, '402', '3'),
(36, 'Manish', 'Kenia', '', 2147483647, '301', 'E'),
(37, 'Pratap', 'Kamble', '', 2147483647, '202', 'C'),
(38, 'Krishna', 'Nabar', '', 2147483647, '202', '4'),
(357, 'sudhanshu', 'bhandarwar', 'srb12031996@gmail.com', 2147483647, '2', 'saraswati'),
(649, 'vasisht', 'shende', 'v@n.com', 965613436, '225', 'hh');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`orderno`);

--
-- Indexes for table `general_maintainance`
--
ALTER TABLE `general_maintainance`
  ADD PRIMARY KEY (`sp_id`),
  ADD KEY `sp_id` (`sp_id`),
  ADD KEY `cleaning_2` (`cleaning`);

--
-- Indexes for table `hardware`
--
ALTER TABLE `hardware`
  ADD UNIQUE KEY `sp_id` (`sp_id`);

--
-- Indexes for table `pest_control`
--
ALTER TABLE `pest_control`
  ADD UNIQUE KEY `sp_id` (`sp_id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`regid`);

--
-- Indexes for table `security`
--
ALTER TABLE `security`
  ADD UNIQUE KEY `sp_id` (`sp_id`);

--
-- Indexes for table `service_provider`
--
ALTER TABLE `service_provider`
  ADD PRIMARY KEY (`sp_id`);

--
-- Indexes for table `society_details`
--
ALTER TABLE `society_details`
  ADD PRIMARY KEY (`society_id`),
  ADD UNIQUE KEY `manager_id` (`manager_id`);

--
-- Indexes for table `society_manager`
--
ALTER TABLE `society_manager`
  ADD PRIMARY KEY (`manager_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hardware`
--
ALTER TABLE `hardware`
  MODIFY `sp_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8601;
--
-- AUTO_INCREMENT for table `pest_control`
--
ALTER TABLE `pest_control`
  MODIFY `sp_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `regid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;
--
-- AUTO_INCREMENT for table `security`
--
ALTER TABLE `security`
  MODIFY `sp_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `service_provider`
--
ALTER TABLE `service_provider`
  MODIFY `sp_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8601;
--
-- AUTO_INCREMENT for table `society_details`
--
ALTER TABLE `society_details`
  MODIFY `society_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=332;
--
-- AUTO_INCREMENT for table `society_manager`
--
ALTER TABLE `society_manager`
  MODIFY `manager_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=650;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `hardware`
--
ALTER TABLE `hardware`
  ADD CONSTRAINT `hardware_ibfk_1` FOREIGN KEY (`sp_id`) REFERENCES `service_provider` (`sp_id`);

--
-- Constraints for table `pest_control`
--
ALTER TABLE `pest_control`
  ADD CONSTRAINT `pest_control_ibfk_1` FOREIGN KEY (`sp_id`) REFERENCES `service_provider` (`sp_id`);

--
-- Constraints for table `security`
--
ALTER TABLE `security`
  ADD CONSTRAINT `security_ibfk_1` FOREIGN KEY (`sp_id`) REFERENCES `service_provider` (`sp_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
