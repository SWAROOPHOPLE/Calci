<?php
require 'connect.php';
if(isset($_REQUEST['send']))
{

$cn=$_REQUEST['cn'];
$mf=$_REQUEST['mf'];
$ml=$_REQUEST['ml'];
$a=$_REQUEST['a'];
$s=$_REQUEST['s'];
$c=$_REQUEST['c'];
$pn=$_REQUEST['pn'];
$em=$_REQUEST['em'];
$un=$_REQUEST['un'];
$pass=$_REQUEST['pass'];
$pc=$_REQUEST['pc'];
$cat=$_REQUEST['cat'];
$sql = "INSERT INTO service_provider(sp_name,sp_phone_no,sp_mf_name,sp_ml_name,sp_area,sp_street,sp_city,sp_common_email,sp_category_id,sp_username,sp_pincode)
									 VALUES
									 ('$cn','$pn','$mf','$ml','$a','$s','$c','$em','$cat','$un','$pc')";
									 
if ($con->query($sql)) 
{
    
//////// echo $c.$f.$a;
} else 
{
	echo (mysql_error($con));

	}
	
	
$sql1 = "INSERT INTO  registration(username,password,type)
									 VALUES
									 ('$un','$pass','service provider')";
									 
if ($con->query($sql1)) 
{
    
//////// echo $c.$f.$a;
} else 
{
	echo (mysql_error($con));

	}
	
	
	
}
$con->close();
?>

<html>

<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	
	<link rel="stylesheet" href="form-basic.css">
	 <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>

<body>
<div class="container">
 
	  
  <br/><br/><br/><br/>
	  <hr/>
 <ul class="nav nav-pills">
  
 
    <li><a  href="index.php"><h3>Home</h3></a></li>
		<li><a href="services.php"><h3>Services</h3></a></li>
		
		<li><a href="profile.html"><h3>My Profile</h3></a></li>
		<li><a href="aboutus.php"><h3>About Us</h3></a></li>
		<br/>
		 <button type="button" class="btn pull-right btn-primary btn-lg" id="signupBtn">Sign Up</button> 
	  <button type="button" class= "btn pull-right btn-success btn-lg" id="logInBtn">Login</button>
  </ul>
  <hr/><br/>
  </div>
  <div class="container-fluid">
<div class="row">
<div class="col-sm-3">
 <div class="list-group">
  <a href="jhome.html" class="list-group-item">Sort-by
  <form action="">
<input type="checkbox" name="vehicle" value="Bike">Area<br>
<input type="checkbox" name="vehicle" value="Car">Alphabetically<br>
<input type="checkbox" name="vehicle" value="Bike">Rating<br>
<input type="checkbox" name="vehicle" value="Car">Popularity<br>
<input type="checkbox" name="vehicle" value="Car">Least Complaint<br>
</form></a>
  <a href="overview.html" class="list-group-item">Show Only
  <form action="">
<input type="checkbox" name="vehicle" value="Bike">Available<br>
<input type="checkbox" name="vehicle" value="Car">10 Km Radius<br>
</form></a>
  <a href="basicsyntax.html" class="list-group-item">Budget
  <form role="form">
    <div class="radio">
      <label><input type="radio" name="optradio">A - B</label>
    </div>
    <div class="radio">
      <label><input type="radio" name="optradio">B - C</label>
    </div>
    <div class="radio">
      <label><input type="radio" name="optradio">C - D</label>
    </div>
    <div class="radio">
      <label><input type="radio" name="optradio"> > D</label>
    </div>

  </form>
</a>
  </div>
</div>
<div class="col-sm-8">
  <div class="container">
    <div class="main-content">


        <form method="post" name="f1" onSubmit="return vali()" class="form-basic" action="#">

            <div class="form-title-row">
                <h3>Service Provider  Signup Form :</h3>
            </div>

            <div class="form-row">
                <label>
                    <span>Company Name</span>
                    <input name="cn" type="text" id="cn" required="required" onChange="return phone()" placeholder="company name"><br/>
					
                </label>
            </div>

			<div class="form-row">
                <label>
                    <span>Manager</span>
					<input name="mf" type="text" id="mf" required="required"  onChange="return phone()" placeholder="firstname"><br/><br/>
					<span> </span><input name="ml" type="text" id="ml" required="required"  onChange="return phone()" placeholder="lastname">
					</label>
            </div>
			
			 <div class="form-row">
                <label>
                    <span>Address:</span>
                    <input name="a" type="text" id="a" required="required" onChange="return phone()" placeholder="Area"><br/><br/>
					<span> </span><input name="s" type="text" id="s" required="required"  onChange="return phone()" placeholder="Street"><br/><br/>
					<span> </span><input name="c" type="text" id="c" required="required"  onChange="return phone()" placeholder="City"> <br/> 
                </label>
            </div>
			
			<div class="form-row">
                <label>
                    <span>Pincode:</span>
                     <input name="pc" type="text" id="pc" required="required"  onChange="return phone()" placeholder="Pincode">
                </label>
            </div>
			
             <div class="form-row">
                <label>
                    <span>Phone No :</span>
                    <input name="pn" type="text" id="pn" required="required" onChange="return phone()" placeholder="Phone Number">
                </label>
            </div>
			
			<div class="form-row">
                <label>
                    <span>Email Id:</span>
                    <input name="em" type="text" id="em" required="required"  onChange="return phone()" placeholder="Email ID">
                </label>
            </div>
			<div id="cat">
			<div class="form-row">
                <label>
                    <span>Catagory</span><br/>
                   <span> </span> <input type="radio" name="cat" value="security" id="sec">Security</input><br/>
                   <span> </span> <input type="radio" name="cat" value="pest control" id="pes">Pest Control</input><br/>
                   <span> </span> <input type="radio" name="cat" value="general maintainance" id="gen">General Maintainance</input><br/>
                   <span> </span> <input type="radio" name="cat" value="hardware" id="har">Hardware</input><br/>
                </label>
            </div>
			</div>
			
			
			<div class="form-row">
                <label>
                    <span>Username:</span>
                    <input name="un" type="text" id="un" required="required" onChange="return phone()" placeholder="Username">
                </label>
            </div>
			
            <div class="form-row">
                <label>
                    <span>Password :</span>
                    <input name="pass" type="password" id="pass" required="required" onChange="return phone()" placeholder="Password">
                </label>
            </div>

            <div class="form-row">
                <label>
                    <span>Confirm Password :</span>
                    <input name="cp" type="text" id="cp" required="required" onChange="return phone()" placeholder="Confirm Password">
					</label>
            </div>

            <div class="form-row">
                <button name="send" type="submit" onclick="gotonextpage()" id="send" value="Send">NEXT </button>
            </div>

        </form>

    </div></div></div>
<script>
function gotonextpage(){
	var value;
	var rates = document.getElementById('cat').value;
	if(document.getElementById('sec').checked){value=document.getElementById('sec').value;}
	else if(document.getElementById('pes').checked){value=document.getElementById('pes').value;}
	else if(document.getElementById('gen').checked){value=document.getElementById('gen').value;}
	else if(document.getElementById('har').checked){value=document.getElementById('har').value;}
	switch(value){
		case security: window.open("security.php"); break;
		case pest control: window.open("pest_control.php"); break;
		case general maintainance: window.open("General_maintainance.php"); break;
		case hardware: window.open("hardware.php"); break;
	}
}
</script>
</body>

</html>






