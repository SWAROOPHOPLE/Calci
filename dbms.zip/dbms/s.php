<?php
require 'connect.php';
if(isset($_REQUEST['send']))
{

$a=$_REQUEST['bn'];
$b=$_REQUEST['by'];
$c=$_REQUEST['bb'];
$d=$_REQUEST['bs'];
$e=$_REQUEST['ba'];
$f=$_REQUEST['bp'];

$sql = "INSERT INTO service_provider(sp_name,sp_phone_no,sp_mf_name,sp_ml_name,sp_area,sp_street)
									 VALUES
									 ('$a','$b','$c','$d','$e','$f')";
if ($con->query($sql)) 
{
    
 echo $c.$f.$a;
} else 
{
	echo (mysql_error($con));

	}
}
$con->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>

<form method="post" enctype="multipart/form-data" name="f1" onSubmit="return vali()">
<table width="366" border="0" align="center">
 
  <tr> <td><div align="center"><font size="+1"  face="Comic Sans MS"><b>comapny name: </b></font></div></td>
    <td><input name="bn" type="text" id="bn" required="required" onChange="return phone()"></td>
  </tr> <tr> <td><div align="center"><font size="+1"  face="Comic Sans MS"><b>manager: </b></font></div></td>
    <td><input name="by" type="text" id="by" required="required"  onChange="return phone()"></td>
  </tr> <tr> <td><div align="center"><font size="+1"  face="Comic Sans MS"><b>area: </b></font></div></td>
    <td><input name="bb" type="text" id="bb" required="required" onChange="return phone()"></td>
  </tr> <tr> <td><div align="center"><font size="+1"  face="Comic Sans MS"><b>phoneno: </b></font></div></td>
    <td><input name="bs" type="text" id="bs" required="required" onChange="return phone()"></td>
  </tr> <tr> <td><div align="center"><font size="+1"  face="Comic Sans MS"><b>email: </b></font></div></td>
    <td><input name="ba" type="text" id="ba" required="required"  onChange="return phone()"></td>
  </tr> <tr> <td><div align="center"><font size="+1"  face="Comic Sans MS"><b>username: </b></font></div></td>
    <td><input name="bp" type="text" id="bp" required="required" onChange="return phone()"></td>
  </tr> 


    <tr>
    <td colspan="2"><label><br>
    <center>
      <input name="send" type="submit" id="send" value="Send">
    </center>
    </label></td>
    </tr>
</table>
 </form>

</body>
</html>


