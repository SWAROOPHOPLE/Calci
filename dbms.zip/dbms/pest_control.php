<?php
require 'connect.php';
$spid=$_REQUEST['spid'];
if(isset($_REQUEST['send']))
{

$from=$_REQUEST['from'];
$to=$_REQUEST['to'];
$com=$_REQUEST['com'];
$hf=$_REQUEST['hf'];
$ants=$_REQUEST['ants'];
$ter=$_REQUEST['ter'];
$rat=$_REQUEST['rat'];
$spi=$_REQUEST['spi'];
$spray=$_REQUEST['spray'];	
$fog=$_REQUEST['fog'];
$sql = "INSERT INTO pest_control(pc_hrf,pc_commercial,house_flies,ant,termites,rat,spider,spray,fog,pc_hrt,sp_id,pc_category_id)
									 VALUES
									 ('$from','$com','$hf','$ants','$ter','$rat','$spi','$spray','$fog','$to','$spid','3')";
if ($con->query($sql)) 
{
    
 //echo $c.$f.$a;
} else 
{
	echo (mysql_error($con));

	}
		header("location:new3.php");
}
$con->close();
?>

<html>

<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	
	<link rel="stylesheet" href="form-basic.css">
	 <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

</head>
<style>
.main-content{
	background:url(back.jpg);
	background-size: cover;
    background-repeat: no-repeat;
}
</style>

<body>
</br>
<div align="center"> <img src="logo1.png" alt="LOGO" width="500" height="100">
</div>

<div class="container">
 
	  
  <br/>
	  <hr/>
	 
 <ul class="nav nav-pills">
  
 
    <li ><a  href="index.php"><h3>Home</h3></a></li>
		<li ><a href="services.php"><h3>Services</h3></a></li>
		
		<li><a href="loginmyp.php"><h3>My Profile</h3></a></li>
		<li><a href="aboutus.php"><h3>About Us</h3></a></li>
		<br/>
		 <button type="button" class="btn pull-right btn-primary btn-lg" id="signupBtn">Sign Up</button> 
	  <button type="button" class= "btn pull-right btn-success btn-lg"><a href="loginmyp.php"><font color="white">Login</font></a></button>
  </ul>
  <hr/><br/>
  </div>
  <div class="modal fade" id="signupModal" role="dialog">
    <div class="modal-dialog">
    
    
      <div class="modal-content">
        <div class="modal-header" style="padding:35px 50px;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4><span class="glyphicon glyphicon-road"></span> Sign Up</h4>
        </div>
        <div class="modal-body" style="padding:40px 50px;">
            
              <a href="society.php"><button type="button" class="btn btn-success btn-block"><span class="glyphicon glyphicon-home"></span><h4> Society</h4></button></a>
			  <br/>
			  <h5 align="center">or</h5><br/>
              <a href="service_provider.php"><button type="button" class="btn btn-success btn-block"><span class="glyphicon glyphicon-user"></span><h4> Service Provider</h4></button></a>
          
        </div>
             </div>
      
    </div>
  </div>
    <div class="main-content" > <br/> <br/>
<div  style="background-color:white;>

        <form method="post" name="f1" onSubmit="return vali()" class="form-basic" action="">

            <div class="form-row">
                <label>
                   <span> Working Hours</span></br>
                    <span>From </span><input name="from" type="text" id="from" required="required"  onChange="return phone()" placeholder="HH:MM"><br/>
					<br/><span>To </span><input name="to" type="text" id="to" required="required"  onChange="return phone()" placeholder="HH:MM">
                </label>
            </div>

			<div class="form-row">
                <label>
                    <span>Commercial </span><br/>
                   <span> </span> <input type="radio" name="com"  required="required" onChange="return phone()" value="yes"> YES </input>
                   <span> </span><input type="radio" name="com"  required="required" onChange="return phone()" value="no">NO </input>
                </label>
            </div>
			
			
			<div class="form-row">
                <label>
                    <span>HouseFlies </span><br/>
                   <span> </span> <input type="radio" name="hf"  required="required" onChange="return phone()" value="yes"> YES </input>
                   <span> </span><input type="radio" name="hf"  required="required" onChange="return phone()" value="no">NO </input>
                </label>
            </div>
			
			
			<div class="form-row">
                <label>
                    <span>Ants </span><br/>
                   <span> </span> <input type="radio" name="ants" required="required" onChange="return phone()"  value="yes"> YES </input>
                   <span> </span><input type="radio" name="ants"  required="required" onChange="return phone()" value="no">NO </input>
                </label>
            </div>
			
			
			<div class="form-row">
                <label>
                    <span>Rats </span><br/>
                   <span> </span> <input type="radio" name="rat"  required="required" onChange="return phone()" value="yes"> YES </input></td>
                   <span> </span><input type="radio" name="rat"  required="required" onChange="return phone()" value="no">NO </input>
                </label>
            </div>
			
			<div class="form-row">
                <label>
                    <span>Spider :</span><br/>
                   <span> </span> <input type="radio" name="spi"  required="required" onChange="return phone()" value="yes"> YES </input>
                   <span> </span><input type="radio" name="spi" required="required" onChange="return phone()"  value="no">NO </input>
                </label>
            </div>
			
			
			<div class="form-row">
                <label>
                    <span>Termites </span><br/>
                   <span> </span> <input type="radio" name="ter"  required="required" onChange="return phone()" value="yes"> YES </input>
                   <span> </span><input type="radio" name="ter" required="required" onChange="return phone()"  value="no">NO </input>
                </label>
            </div>
			
			<div class="form-row">
                <label>
                    <span>Spray </span><br/>
                   <span> </span> <input type="radio" name="spray" required="required" onChange="return phone()"  value="yes"> YES </input>
                   <span> </span><input type="radio" name="spray"  required="required" onChange="return phone()" value="no">NO </input>
                </label>
            </div>
			
			
			<div class="form-row">
                <label>
                    <span>Fog </span><br/>
                   <span> </span> <input type="radio" name="fog" required="required" onChange="return phone()"  value="yes"> YES </input>
                   <span> </span><input type="radio" name="fog" required="required" onChange="return phone()" value="no">NO </input>
                </label>
            </div>
			
			
			
			
            <div class="form-row">
                <button name="send" type="submit" id="send" onclick="gotonextpage()"  value="Send">Submit Form</button>
            </div>

        </form>
</div>
    </div>
<script>

$(document).ready(function(){
    $("#signupBtn").click(function(){
        $("#signupModal").modal();
    });
});
</script>
</body>

</html>
