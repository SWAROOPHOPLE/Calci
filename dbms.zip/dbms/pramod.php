
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cz">
<?php
error_reporting(1);

?>
     <head>
	 <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

	
	<style>

</style>
  <style>

table {
    border-collapse: collapse;
    width: 100%;
	margin:2;
}

th, td {
    text-align: center;
    padding: 13px;
}



th {
    background-color:#3f3f3f;
    color: white;
}
</style>
    <style>
	
     
    </style>
	<style>
.center {
    margin: auto;
    width: 60%;
    padding: 100px;
}

     
	   .a{
    opacity: 0.7;
    filter: alpha(opacity=50); 
	}
	.ascroll{
		max-height:605px;
		overflow-y:scroll;
	}
	.bscroll{
		max-height:600px;
		overflow-y:scroll;
	}
</style>
    </head>
	
<body >
</br>
<div align="center"> <img src="logo1.png" alt="LOGO" width="500" height="100">
</div>
<div class="modal fade" id="signupModal" role="dialog">
    <div class="modal-dialog">
    
    
      <div class="modal-content">
        <div class="modal-header" style="padding:35px 50px;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4><span class="glyphicon glyphicon-road"></span> Sign Up</h4>
        </div>
        <div class="modal-body" style="padding:40px 50px;">
            
              <a href="society.php"><button type="button" class="btn btn-success btn-block"><span class="glyphicon glyphicon-home"></span><h4> Society</h4></button></a>
			  <br/>
			  <h5 align="center">or</h5><br/>
              <a href="service_provider.php"><button type="button" class="btn btn-success btn-block"><span class="glyphicon glyphicon-user"></span><h4> Service Provider</h4></button></a>
          
        </div>
             </div>
      
    </div>
  </div> 
 <div class="container">
	  
  <br/>
	  <hr/>
 <ul class="nav nav-pills">
  
 
    <li><a  href="index.php"><h3>Home</h3></a></li>
		<li class="active"><a href="services.php"><h3>Services</h3></a></li>
		<li><a href="loginmyp.php"><h3>My Profile</h3></a></li>
		<li><a href="aboutus.php"><h3>About Us</h3></a></li>
		<br/>
		 <button type="button" class="btn pull-right btn-primary btn-lg" id="signupBtn">Sign Up</button> 
	  <button type="button" class= "btn pull-right btn-success btn-lg"><a href="loginmyp.php"><font color="white">Login</font></a></button>
  </ul>
  <hr/><br/></div>
	<div class="container-fluid">

  <div class="container">
    <?php
$cnd=$_REQUEST['cate'];
 require "connect.php";
 if($cnd=='1')
	 {           
		 $sql="select * from general_maintainance";
    $row = $con->query($sql);
	
    echo "<table align='center'><tr> <th>Name</th><th>Cleaning</th><th>Gardening</th><th>Lift</th><th>Club</th><th>CarWash</th><th>StartTime</th><th>End Time
	</th><th></th></tr>";
        while($arr = $row->fetch_assoc()) 
        {
			   
              $bi=$arr['cleaning'];
			  $bn=$arr['gardening'];
			  $bss=$arr['gm_lift'];
			  $bb=$arr['gm_club'];
			  $bu=$arr['car_wash'];
			  $bp=$arr['start_time'];
			  $bpr=$arr['end_time'];
			  $bd=$arr['sp_id'];	
                   
		 $scl="select * from service_provider where sp_id='$bd'";
    $rowb = $con->query($scl);
	 while($arb = $rowb->fetch_assoc()) 
	 {
		 $bk=$arb['sp_name'];
	 }
				  
       echo "<tr><td>" .$bk."</td><td>" . $bi."</td><td>" . $bn."</td><td>" . $bss."</td><td>" . $bb."</td><td>" . $bu."</td>
	   <td>" . $bp."</td><td>" . $bpr."</td>
	   <td><a href='login.php?itemno=$bd'><img src='book1.jpeg' width='100' height='40'/></a></td></tr>";
        }
          echo "</table>";
		
	 }
	 else if($cnd=='2')
	 {
		 $sql="select * from hardware";
    $row = $con->query($sql);
    echo "<table align='center'><tr> <th>Name</th><th>start_time</th><th>end_time</th><th>plumbing</th><th>electricWork</th><th>woodWork</th><th>GlassWork</th><th>Masonary</th><th>Painters</th><th></th>
	</tr>";
        while($arr = $row->fetch_assoc()) 
        {
              $bi=$arr['start_time'];
			  $bn=$arr['end_time'];
			  $bss=$arr['hd_plumbing'];
			  $bb=$arr['hd_electric_work'];
			  $bu=$arr['hd_wood_work'];
			  $bp=$arr['hd_glass_work'];
			  $bpr=$arr['hd_masonary'];
			  $bprd=$arr['hd_painters'];
			  $bs=$arr['sp_id'];
			 
		 $scl="select * from service_provider where sp_id='$bs'";
    $rowb = $con->query($scl);
	 while($arb = $rowb->fetch_assoc()) 
	 {
		 $bk=$arb['sp_name'];
	 }

       echo "<tr><td>" .$bk."</td><td>" . $bi."</td><td>" . $bn."</td><td>" . $bss."</td><td>" . $bb."</td><td>" . $bu."</td>
	   <td>" . $bp."</td><td>" . $bpr."</td><td>" . $bprd."</td>
	   <td><a href='login.php?itemno=$bs'><img src='book1.jpeg' width='100' height='40'/></a></td></tr>";
        }
          echo "</table>";

	 }
	 else if($cnd=='3')
	 {
		  $sql="select * FROM pest_control";
    $row = $con->query($sql);
    echo "<table align='center'><tr> <th>Name</th><th>From</th><th>To</th><th>Commercial</th>
	<th>House Flies</th><th>Ants</th><th>Termites</th><th>Rat</th><th>Spiders</th><th>Spray Treatment</th><th>Fog Treatment</th><th></th>
	</tr>";
        while($arr = $row->fetch_assoc()) 
        {
			   $oun=$arr['pc_hrf'];
               $on=$arr['pc_hrt'];
			   $os=$arr['pc_commercial'];
			   $oa=$arr['house_flies'];
			   $opm=$arr['ant'];
			   $ops=$arr['termites'];
			   $pt=$arr['rat'];
			   $oc=$arr['spider'];
			   $occ=$arr['spray'];
			   $obi=$arr['fog'];
			   $om=$arr['sp_id'];
              
			 
		 $scl="select * from service_provider where sp_id='$om'";
    $rowb = $con->query($scl);
	 while($arb = $rowb->fetch_assoc()) 
	 {
		 $bk=$arb['sp_name'];
	 }
            
              			 
       echo "<tr><td>" .$bk."</td><td>" .$oun."</td><td>" . $on."</td><td>" . $os."</td><td>" .$oa."</td><td>" . $opm."</td><td>" . $ops."</td><td>" . $pt."</td>
	   <td>" . $oc."</td><td>" . $occ."</td><td>" . $obi."</td>
	   <td><a href='login.php?itemno=$om'><img src='book1.jpeg' width='100' height='40'/></a></td></tr>";
        }
          echo "</table>";
	 }
	  else if($cnd=='4')
	 {
		 $sql="select * from security";
    $row = $con->query($sql);
    echo "<table align='center'><tr> <th>Name</th><th>Availibility of staff</th><th>Minimum Age of Staff</th><th>Maximum Age of Staff</th><th>Grade of Security</th><th></th></tr>";
        while($arr = $row->fetch_assoc()) 
        {
               $ci=$arr['s_avai_staff'];
			   $cu=$arr['age_min'];
			   $cn=$arr['age_max'];
			   $cm=$arr['s_certification'];
			   
			   $ce=$arr['sp_id'];
		 $scl="select * from service_provider where sp_id='$ce'";
    $rowb = $con->query($scl);
	 while($arb = $rowb->fetch_assoc()) 
	 {
		 $bk=$arb['sp_name'];
	 }
              
            
              			 
       echo "<tr><td>" .$bk."</td><td>" .$ci."</td><td>" . $cu."</td><td>" . $cn."</td><td>" . $cm."</td>
	   
	 <td><a href='login.php?itemno=$ce'><img src='book1.jpeg' width='100' height='40'/></a></td></tr>";
        }
          echo "</table>";
		  
	 }
	 
if($_REQUEST['cate']=="")
{
	header("location:index2.php");
}	
error_reporting(1);
?>
</div></div>
<script>

$(document).ready(function(){
    $("#signupBtn").click(function(){
        $("#signupModal").modal();
    });
});
</script>
    </body>
    </html>
