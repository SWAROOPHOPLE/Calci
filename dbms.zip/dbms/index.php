<?php
error_reporting(1);

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Society Management</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <style>
  body{
  background-image:url(Hback3.jpg)
  }
  .carousel-inner > .item > img,
  .carousel-inner > .item > a > img {
      width: 100%;
      margin: auto;
	  }
.abc{
    background-color:#f2f2f2;
    }	  
	  
 .bg-4 { 
      background-color: #2f2f2f; /* Black Gray */
      color: #fff;
	   padding-top: 70px;
      padding-bottom: 70px;
  }	  
	  
  </style>
 </head>
<body>
</br>
<div align="center"> <img src="logo1.png" alt="LOGO" width="500" height="100">
</div>

<div class="container">
 
	  
  <br/>
	  <hr/>
 <ul class="nav nav-pills">
  
 
    <li class="active"><a  href="index.php"><h3>Home</h3></a></li>
		<li ><a href="services.php"><h3>Services</h3></a></li>
		
		 <?php
 	session_start();
     $id=$_SESSION['eid'];
    if($id!="")
	{echo"<li><a href='?log=out'><h3>My Profile</h3></a></li>";
		echo"<button type='button' class= 'btn pull-right btn-success btn-lg'><a href='?log=out'><font color='white'>Logout</font></a></button>";}
    else {echo"<li><a href='loginmyp.php'><h3>My Profile</h3></a></li>";
	    echo"<button type='button' class='btn pull-right btn-primary btn-lg' id='signupBtn'>Sign Up</button> 
	  <button type='button' class= 'btn pull-right btn-success btn-lg'><a href='loginmyp.php'><font color='white'>Login</font></a></button>";
	   
	   
   }
   
   if(isset($_REQUEST['log'])=='out')
{
session_destroy();
header("location:loginmyp.php");
}

   ?>
<li><a href="aboutus.php"><h3>About Us</h3></a></li>
		<br/>
		 
 
  </ul>
  <hr/><br/>
  </div>
  <div class="modal fade" id="signupModal" role="dialog">
    <div class="modal-dialog">
    
    
      <div class="modal-content">
        <div class="modal-header" style="padding:35px 50px;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4><span class="glyphicon glyphicon-road"></span> Sign Up</h4>
        </div>
        <div class="modal-body" style="padding:40px 50px;">
            
              <a href="society.php"><button type="button" class="btn btn-success btn-block"><span class="glyphicon glyphicon-home"></span><h4> Society</h4></button></a>
			  <br/>
			  <h5 align="center">or</h5><br/>
              <a href="service_provider.php"><button type="button" class="btn btn-success btn-block"><span class="glyphicon glyphicon-user"></span><h4> Service Provider</h4></button></a>
          
        </div>
             </div>
      
    </div>
  </div> 
  <div class="container">
  
  <!--for slideshow of photoes-->
  <br>
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
      <div class="item active">
        <img src="pic1.jpg" alt="service 1" width="460" height="345">
      </div>

      <div class="item">
        <img src="pic2.jpg" alt="service 2" width="460" height="345">
      </div>
    
      <div class="item">
        <img src="pic3.jpg" alt="service 3" width="460" height="345">
      </div>

      <div class="item">
        <img src="pic4.jpg" alt="servic 4" width="460" height="345">
      </div>
    </div>

    
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
  </div>
 </br></br>
 <div class="container">
  <div class="abc">
 <div class="row">
  <div class="col-sm-6"><h3><strong>Area</strong></h3></br>
  <ul>
<h3>  <li>Mumbai</li></h3>

  </ul>
  </div>
  <div class="col-sm-6"><h3><strong>Services</strong></h3></br>
  <li><h4>Pest Control</h4>
  <ul>
  <li>House Flies</li>
  <li>Rats</li>
  <li>Ants</li>
  <li>Termites</li>
  <li>Spider</li>
  <li>Snakes</li></ul></li>
  <li><h4>Hardware</h4><ul><li>Plumbing</li><li>Electric Works</li><li>Glass Work</li><li>Wood Work </li><li>Painters</li><li>Masonary</li></ul></li>
  <li><h4>General Maintainance</h4><ul><li>Cleaning</li><li>Gardening</li><li>Lift Work</li><li>Club Work</li><li>Car Wash</li></ul></li>
  <li><h4>Security</h4></li></br></br></div>
</div>
</div>
</div>
  
</br></br>
</br></br></br>


<script>

$(document).ready(function(){
    $("#signupBtn").click(function(){
        $("#signupModal").modal();
    });
});
</script>
</body>
</html>
