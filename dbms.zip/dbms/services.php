<?php
error_reporting(1);

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Society Management</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <style>
 

  
  </style>
</head>
<body >
  </br>
<div align="center"> <img src="logo1.png" alt="LOGO" width="500" height="100">
</div>
   <div class="modal fade" id="signupModal" role="dialog">
    <div class="modal-dialog">
    
    
      <div class="modal-content">
        <div class="modal-header" style="padding:35px 50px;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4><span class="glyphicon glyphicon-road"></span> Sign Up</h4>
        </div>
        <div class="modal-body" style="padding:40px 50px;">
            
              <a href="society.php"><button type="button" class="btn btn-success btn-block"><span class="glyphicon glyphicon-home"></span><h4> Society</h4></button></a>
			  <br/>
			  <h5 align="center">or</h5><br/>
              <a href="service_provider.php"><button type="button" class="btn btn-success btn-block"><span class="glyphicon glyphicon-user"></span><h4> Service Provider</h4></button></a>
          
        </div>
             </div>
      
    </div>
  </div> 
	<div class="container">
	  
  <br/>
	  <hr/>
 <ul class="nav nav-pills">
  
 
    <li><a  href="index.php"><h3>Home</h3></a></li>
		<li class="active"><a href="services.php"><h3>Services</h3></a></li>
		
		
		
 <?php
 	session_start();
$id=$_SESSION['eid'];
    if($id!="")
	{echo"<li><a href='?log=out'><h3>My Profile</h3></a></li>";
		echo"<button type='button' class= 'btn pull-right btn-success btn-lg'><a href='?log=out'><font color='white'>Logout</font></a></button>";}
   else {echo"<li><a href='loginmyp.php'><h3>My Profile</h3></a></li>";
	    echo"<button type='button' class='btn pull-right btn-primary btn-lg' id='signupBtn'>Sign Up</button> 
	  <button type='button' class= 'btn pull-right btn-success btn-lg'><a href='loginmyp.php'><font color='white'>Login</font></a></button>";
	   
	   
   }
   
   if(isset($_REQUEST['log'])=='out')
{
session_destroy();
header("location:loginmyp.php");
}

   ?>
<li><a href="aboutus.php"><h3>About Us</h3></a></li>
		<br/>
		 
 </ul></br>
  <hr/><br/>
	  <div class="panel-group">
		
		<div class="panel panel-info">
			<div class="panel-heading">SECURITY</div>
			<div class="panel-body">
				Book Security agencies for providing watchmen to guard your society. Some agencies also provide electronic security devices to feel more secure. BOOK the perfect agency now!!
			</div>
			<div class="panel-footer clearfix">
				For more information contact us...
				<button type="button" class="btn btn-info pull-right"><?php session_destroy(); echo"<a href='pramod.php?cate=4'> <font color='white'>BOOK NOW!!</font></a>";?></button>
			</div>
		</div>
			
		<div class="panel panel-info">
			<div class="panel-heading">PEST CONTROL</div>
			<div class="panel-body">
				Book the best rated Pest Control services around your society if you are facing any kind of Pest problems.
			</div>
			<div class="panel-footer clearfix">
				For more information contact us...
				<button type="button" class="btn btn-info pull-right" ><?php session_destroy(); echo"<a href='pramod.php?cate=3'> <font color='white'>BOOK NOW!!</font></a>";?></button>
			</div>
		</div>
		<div class="panel panel-info">
			<div class="panel-heading">HARDWARE</div>
			<div class="panel-body">
				Any leakage in the pipelines or any problem with the wiring of your society? We provide professional plumbers and electricians to be booked here. So Book now!!
			</div>
			<div class="panel-footer clearfix">
				For more information contact us...
				<button type="button" class="btn btn-info pull-right"><?php session_destroy(); echo"<a href='pramod.php?cate=2'> <font color='white'>BOOK NOW!!</font></a>";?></button>
			</div>
		</div>
		<div class="panel panel-info">
			<div class="panel-heading">GENERAL MAINTAINANCE</div>
			<div class="panel-body">
				Book maintainance agencies which provide monthly, quarterly or annual maintainance services for various mechanical and electrical devices.
			</div>
			<div class="panel-footer clearfix">
				For more information contact us...
				<button type="button" class="btn btn-info pull-right" ><?php session_destroy(); echo"<a href='pramod.php?cate=1'> <font color='white'>BOOK NOW!!</font></a>";?></button>
			</div>
		</div>
	  </div>
	</div>
	
<script>

$(document).ready(function(){
    $("#signupBtn").click(function(){
        $("#signupModal").modal();
    });
});
</script>
</body>  
</html>
  