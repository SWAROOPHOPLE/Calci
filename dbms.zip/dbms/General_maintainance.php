<?php
require 'connect.php';
$spid=$_REQUEST['spid'];
if(isset($_REQUEST['send']))
{

$from=$_REQUEST['from'];
$to=$_REQUEST['to'];
$cleaning=$_REQUEST['cleaning'];
$gar=$_REQUEST['gar'];
$lift=$_REQUEST['lift'];
$club=$_REQUEST['club'];
$car=$_REQUEST['car'];

$sql = "INSERT INTO general_maintainance(start_time,end_time,cleaning,gardening,gm_lift,gm_club,car_wash,sp_id,gm_category_id)
									 VALUES
									 ('$from','$to','$cleaning','$gar','$lift','$club','$car','$spid','1')";
if ($con->query($sql)) 
{
    
 //echo $c.$f.$a;
} else 
{
	echo (mysql_error($con));

	}
		header("location:new3.php");
}
$con->close();
?>
<html>


<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	
	<link rel="stylesheet" href="form-basic.css">
	 <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<style>
.main-content{
	background:url(back.jpg);
	background-size: cover;
    background-repeat: no-repeat;
}
</style>

<body>
</br>
<div align="center"> <img src="logo1.png" alt="LOGO" width="500" height="100">
</div>
   <div class="modal fade" id="signupModal" role="dialog">
    <div class="modal-dialog">
    
    
      <div class="modal-content">
        <div class="modal-header" style="padding:35px 50px;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4><span class="glyphicon glyphicon-road"></span> Sign Up</h4>
        </div>
        <div class="modal-body" style="padding:40px 50px;">
            
              <a href="society.php"><button type="button" class="btn btn-success btn-block"><span class="glyphicon glyphicon-home"></span><h4> Society</h4></button></a>
			  <br/>
			  <h5 align="center">or</h5><br/>
              <a href="service_provider.php"><button type="button" class="btn btn-success btn-block"><span class="glyphicon glyphicon-user"></span><h4> Service Provider</h4></button></a>
          
        </div>
             </div>
      
    </div>
  </div> 


<div class="container">
 
	  
  <br/>
	  <hr/>
 <ul class="nav nav-pills">
  
 
    <li class="active"><a  href="index.php"><h3>Home</h3></a></li>
		<li ><a href="services.php"><h3>Services</h3></a></li>
		
		<li><a href="loginmyp.php"><h3>My Profile</h3></a></li>
		<li><a href="aboutus.php"><h3>About Us</h3></a></li>
		<br/>
		 <button type="button" class="btn pull-right btn-primary btn-lg" id="signupBtn">Sign Up</button> 
	  <button type="button" class= "btn pull-right btn-success btn-lg"><a href="loginmyp.php"><font color="white">Login</font></a></button>
  </ul>
  <hr/><br/>
  </div>
  <div class="modal fade" id="signupModal" role="dialog">
    <div class="modal-dialog">
    
    
      <div class="modal-content">
        <div class="modal-header" style="padding:35px 50px;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4><span class="glyphicon glyphicon-road"></span> Sign Up</h4>
        </div>
        <div class="modal-body" style="padding:40px 50px;">
            
              <a href="society.php"><button type="button" class="btn btn-success btn-block"><span class="glyphicon glyphicon-home"></span><h4> Society</h4></button></a>
			  <br/>
			  <h5 align="center">or</h5><br/>
              <a href="service_provider.php"><button type="button" class="btn btn-success btn-block"><span class="glyphicon glyphicon-user"></span><h4> Service Provider</h4></button></a>
          
        </div>
             </div>
      
    </div>
  </div> 

    <div class="main-content"> <br/> <br/>

<div  style="background-color:white;>
        <form method="post" name="f1" onSubmit="return vali()" class="form-basic" action="">

            <div class="form-row">
                <label>
                    <span>Hours of operation </span> </br>
                    <span>From </span><input name="from" type="text" id="from" required="required"  onChange="return phone()" placeholder="hh:mm"></br>
					<br/><span>To </span><input name="to" type="text" id="to" required="required"  onChange="return phone()" placeholder="hh:mm">
                </label>
            </div>

			<div class="form-row">
                <label>
                    <span>Services Offered </span>
            </div>
			
			
			<div class="form-row">
                <label>
                    <span>Cleaning </span><br/>
    <span></span> <input type="radio" name="cleaning"  required="required" onChange="return phone()" value="yes"> YES </input>
    <span></span> <input type="radio" name="cleaning"  required="required" onChange="return phone()" value="no">NO </input>
  
                </label>
            </div>
			
			
			<div class="form-row">
                <label>
                    <span>Gardening </span><br/>
    <span></span> <input type="radio" name="gar"  required="required" onChange="return phone()" value="yes"> YES </input>
    <span></span> <input type="radio" name="gar"  required="required" onChange="return phone()" value="no">NO </input>
  
                </label>
            </div>
			
			<div class="form-row">
                <label>
                    <span>Lift Maintainance </span><br/>
    <span></span> <input type="radio" name="lift"  required="required" onChange="return phone()" value="yes"> YES </input>
    <span></span> <input type="radio" name="lift"  required="required" onChange="return phone()" value="no">NO </input>
  
                </label>
            </div>
			
			<div class="form-row">
                <label>
                    <span>Club </span><br/>
    <span></span> <input type="radio" name="club"  required="required" onChange="return phone()" value="yes"> YES </input>
    <span></span> <input type="radio" name="club"  required="required" onChange="return phone()" value="no">NO </input>
  
                </label>
            </div>
			
			<div class="form-row">
                <label>
                    <span>Car Washing </span><br/>
    <span></span> <input type="radio" name="car"  required="required" onChange="return phone()" value="yes"> YES </input>
    <span></span> <input type="radio" name="car"  required="required" onChange="return phone()" value="no">NO </input>
  
                </label>
            </div>
			
			
			
			
			
            <div class="form-row">
                <button name="send" type="submit" id="send" onclick="gotonextpage()"  value="Send">Submit Form</button>
            </div>

        </form>
</div>
    </div>

<script>

$(document).ready(function(){
    $("#signupBtn").click(function(){
        $("#signupModal").modal();
    });
});
</script>
</body>

</html>
