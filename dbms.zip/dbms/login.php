<?php


$i=$_REQUEST['itemno'];

include("config.php");

if(isset($_REQUEST['btn-login']))
{
$id=$_REQUEST['usr'];
$pass=$_REQUEST['pass'];
   $sel=mysql_query("select username,password from registration where   username='$id'");
  $arr=mysql_fetch_array($sel);
if(($arr['username']==$id) and( $arr['password']==$pass))
  {
  session_start();
   $_SESSION['eid']=$id;

echo "<script>location.href='booknow.php?itemno=$i&usrm=$id'</script>";
   }
else
{
	echo "<script>location.href='index2.php'</script>";
	
$error="id and password do not match";
}
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
 <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title> Login</title>
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
<link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen">
<link rel="stylesheet" href="style.css" type="text/css"  />
<style>
 .main-content
      {
        background-image:url(back.jpg);
        background-position:0px 0px;
    background-size: cover;
        background-repeat: repeat;
      }
	  </style>
</head>
<body>
</br>
<div align="center"> <img src="logo1.png" alt="LOGO" width="500" height="100">
</div>

<div class="container">
 
	  <br/>
	 <hr/>
 <ul class="nav nav-pills">
  
 
    <li><a  href="index.php"><h3>Home</h3></a></li>
		<li ><a href="services.php"><h3>Services</h3></a></li>
		
		<li><a href="loginmyp.php"><h3>My Profile</h3></a></li>
		<li><a href="aboutus.php"><h3>About Us</h3></a></li>
		<br/>
		 <button type="button" class="btn pull-right btn-primary btn-lg"><a href="society.php"><font color="white">Sign Up</font></a></button> 
	
  </ul>
 <hr/><br/>
  </div>
  
   <div class="main-content">
   <div class="container">
   <br/><br/><br/>
<div class="row">
    <div class="col-sm-4"></div>
    <div class="col-sm-4" style="background-color:white;">
	<div class="signin-form">

     
        
       <form class="form-signin" method="post" id="login-form" >
	   <br/>
      
        <h2 class="form-signin-heading">LOG IN</h2><br/>    
        <div id="error">
       
        </div>
        
        <div class="form-group">
        <input type="text" class="form-control" name="usr" placeholder="Username" required />
        <span id="check-e"></span>
        </div>
       
        <div class="form-group">
        <input type="password" class="form-control" name="pass" placeholder="Your Password" />
        </div>
       
     	
        
        <div class="form-group">
            <button type="submit" name="btn-login" class="btn btn-default">
                	<i class="glyphicon glyphicon-log-in"></i> &nbsp; SIGN IN
            </button>
        </div>  
      	<br />
            <label>Don't have an account yet ! <a href="society.php">&nbsp;Sign Up</a></label>
				<br />
            <label>Forget Password<a href="forgetpassword.php">&nbsp;click here</a></label>
			<br/><br/>
      </form>

    </div>
    
</div></div></div></br></br></div>
    <div class="col-sm-4"></div>
  </div>
  <br/><br/><br/>
  </div>


	 
</body>
</html>