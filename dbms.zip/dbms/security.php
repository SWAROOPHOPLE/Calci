<?php
require 'connect.php';
$spid=$_REQUEST['spid'];
if(isset($_REQUEST['send']))
{

$as=$_REQUEST['as'];
$from=$_REQUEST['from'];
$to=$_REQUEST['to'];
$cer=$_REQUEST['cer'];



$sql = "INSERT INTO security(s_avai_staff,age_min,age_max,s_certification,s_category_id,sp_id)
									 VALUES
									 ('$as','$from','to','$cer','4','$spid')";
									 
									 
if ($con->query($sql)) 
{
    
 //echo $c.$f.$a;
} else 
{
	echo (mysql_error($con));

	}
		header("location:new3.php");
}
$con->close();
?>
<html>

<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	
	<link rel="stylesheet" href="form-basic.css">
	 <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<style>
.main-content{
	background:url(back.jpg);
	background-size: cover;
    background-repeat: no-repeat;
}
</style>

<body>
</br>
<div align="center"> <img src="logo1.png" alt="LOGO" width="500" height="100">
</div>

<div class="container">
 
	  
  <br/>
	  <hr/>
 <ul class="nav nav-pills">
  
 
    <li><a  href="index.php"><h3>Home</h3></a></li>
		<li ><a href="services.php"><h3>Services</h3></a></li>
		
		<li><a href="loginmyp.php"><h3>My Profile</h3></a></li>
		<li><a href="aboutus.php"><h3>About Us</h3></a></li>
		<br/>
		 </ul>
  <hr/><br/>
  </div>
  

    <div class="main-content"> <br/> <br/>


        <form method ="post" name="f1" onSubmit="return vali()" class="form-basic" action="">
			
            <div class="form-row">

                <label>
                    <span>Staff Availablity </span>
                    <input name="as" type="text" id="as" required="required" onChange="return phone()" placeholder="Availibility of Staff">
                </label>
            </div>

			<div class="form-row">
			    <span>Staff Age </span><br/>
                <label>
                    <span>From </span><input name="from" type="text" id="from" required="required"  onChange="return phone()" placeholder="From">
				<br/><br/> <span>To </span><input name="to" type="text" id="to" required="required"  onChange="return phone()" placeholder="To">
            </div>
			
			
			<div class="form-row">
                <label>
                    <span>Certification </span><br/>
    <span></span> <input type="radio" name="cer" required="required" onChange="return phone()"  value="A"> A </input><br/>
   <span></span> <input type="radio" name="cer" required="required" onChange="return phone()"  value="B"> B </input><br/>
   <span></span> <input type="radio" name="cer" required="required" onChange="return phone()"  value="C"> C </input><br/>
   <span></span> <input type="radio" name="cer" required="required" onChange="return phone()"  value="D"> D </input><br/>
                </label>
            </div>
			
			
			
			
			
			
            <div class="form-row">
                <button name="send" type="submit" id="send" onclick="gotonextpage()"  value="Send">Submit Form</button>
            </div>

        </form>
</div>
  

</body>

</html>
