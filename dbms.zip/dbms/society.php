<?php
require 'connect.php';
if(isset($_REQUEST['send']))
{

$sn=$_REQUEST['sn'];
$a=$_REQUEST['a'];
$s=$_REQUEST['s'];
$c=$_REQUEST['c'];
$pc=$_REQUEST['pc'];
$pn=$_REQUEST['pn'];
$em=$_REQUEST['em'];
$nb=$_REQUEST['nb'];
$doe=$_REQUEST['doe'];
$nf=$_REQUEST['nf'];
$nfl=$_REQUEST['nfl'];
$nl=$_REQUEST['nl'];
$sn=$_REQUEST['sn'];
$mf=$_REQUEST['mf'];
$ml=$_REQUEST['ml'];
$mpn=$_REQUEST['mpn'];
$mfn=$_REQUEST['mfn'];
$mbn=$_REQUEST['mbn'];
$mem=$_REQUEST['mem'];
$un=$_REQUEST['un'];
$pass=$_REQUEST['pass'];
$id=rand(1,999);
$sql = "INSERT INTO society_details(society_name, phone_no,manager_id, area_name, street_name, city, society_email, bldg_nos, floor_nos, flat_per_floor, lifts_no, society_area, estd_date, username, society_pincode)
VALUES ('$sn', '$pn','$id', '$a', '$s', '$c', '$em', '$nb', '$nf', '$nfl', '$nl', '110', '$doe', '$un', '$pc')";

if ($con->query($sql)) 
{
    
 //echo $c.$f.$a;
} else 
{
	echo mysql_error();


	}

$sql1 = "INSERT INTO   society_manager ( mf_name, ml_name,manager_id, sm_email_id, sm_phone_no, sm_flat_no, sm_bldg_name   )
VALUES ('$mf', '$ml','$id','$mem', '$mpn', '$mfn', '$mbn')";



if ($con->query($sql1)) 
{
    
 //echo $c.$f.$a;
} else 
{
	echo mysql_error();

	}

$sql2 = "INSERT INTO  registration(username,password,type)
									 VALUES
									 ('$un','$pass','1')";
									 
if ($con->query($sql2)) 
{
    
//////// echo $c.$f.$a;
} else 
{
	echo (mysql_error($con));

	}


header("location:new3.php");	
}

$con->close();
?>
<html>

<head>

	<meta charset="utf-8">
	
	<meta name="viewport" content="width=device-width, initial-scale=1">

	
	<link rel="stylesheet" href="form-basic.css">
	 <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<style>
.main-content{
	background:url(back.jpg);
	background-size: cover;
    background-repeat: no-repeat;
}
</style>
</head>

<body>
</br>
<div align="center"> <img src="logo1.png" alt="LOGO" width="500" height="100">
</div>
<div class="container">
 
	  
  <br/>
	  <hr/>
 <ul class="nav nav-pills">
  
 
    <li><a  href="index.php"><h3>Home</h3></a></li>
		<li><a href="services.php"><h3>Services</h3></a></li>
		
		<li><a href="loginmyp.php"><h3>My Profile</h3></a></li>
		<li><a href="aboutus.php"><h3>About Us</h3></a></li>
		<br/>
	  <button type="button" class= "btn pull-right btn-success btn-lg" ><a href="loginmyp.php"><font color="white">Login</font></a></button>
  </ul>
  <hr/><br/>
  </div>

    <div class="main-content">
</br></br>

        <form method="post" name="f1" onSubmit="return vali()" class="form-basic" action="">

            <div class="form-title-row">
                <h3>Society Signup Form </h3>
            </div>

            <div class="form-row">
                <label>
                    <span>Society Name </span><input name="sn" type="text" id="sn" required="required" onChange="return phone()" placeholder="Society Name"><br/>
					
                </label>
            </div>

			<div class="form-row">
                <label>
                    <span>Address </span><input name="a" type="text" id="a" required="required" onChange="return phone()" placeholder="Area"><br/><br/>
					<span></span><input name="s" type="text" id="s" required="required"  onChange="return phone()" placeholder="Street"><br/><br/>
					<span></span><input name="c" type="text" id="c" required="required"  onChange="return phone()" placeholder="City">
					</label>
            </div>
			
			 <div class="form-row">
                <label>
                    <span>Pincode </span><input name="pc" type="text" id="pc" required="required"  onChange="return phone()" placeholder="Pincode">
				</label>
            </div>
			
			<div class="form-row">
                <label>
                    <span>Phone No </span><input name="pn" type="text" id="pn" required="required" onChange="return phone()" placeholder="Phone Number">
                </label>
            </div>
			
             <div class="form-row">
                <label>
                    <span>Email Id </span><input name="em" type="email" id="em" required="required"  onChange="return phone()" placeholder="Email ID">
                </label>
            </div>
			
			<div class="form-row">
                <label>
                    <span>Number Of Buildings </span><input name="nb" type="text" id="nb" required="required"  onChange="return phone()" placeholder="Number of bldgs">
                </label>
            </div>
			
			<div class="form-row">
                <label>
                    <span>Date Of Establishment </span><input name="doe" type="date" id="doe" required="required"  onChange="return phone()" placeholder="Date">
                </label>
            </div>
			
			
			<div class="form-row">
                <label>
                    <span>Number Of Floors </span><input name="nf" type="text" id="nf" required="required"  onChange="return phone()" placeholder="Floors">
                </label>
            </div>

			
			
			<div class="form-row">
                <label>
                    <span>Flats Per Floor </span><input name="nfl" type="text" id="nfl" required="required"  onChange="return phone()" placeholder="Flats">
                </label>
            </div>

			<div class="form-row">
                <label>
                    <span>Number Of Lifts </span><input name="nl" type="text" id="nl" required="required"  onChange="return phone()" placeholder="Lifts">
                </label>
            </div>

			<div class="form-row">
                <label>
                    <span>Manager First Name </span><input name="mf" type="text" id="mf" required="required"  onChange="return phone()" placeholder="first name">
                </label>
            </div>

			<div class="form-row">
                <label>
                    <span>Manager Last Name :</span><input name="ml" type="text" id="ml" required="required"  onChange="return phone()" placeholder="last name">
                </label>
            </div>

			<div class="form-row">
                <label>
                    <span>Phone Number </span><input name="mpn" type="text" id="mpn" required="required"  onChange="return phone()" placeholder="phone no">
                </label>
            </div>

			<div class="form-row">
                <label>
                    <span>Flat Number </span><input name="mfn" type="text" id="mfn" required="required"  onChange="return phone()" placeholder="flat no">
                </label>
            </div>

			<div class="form-row">
                <label>
                    <span>Building Name </span>
                    <input name="mbn" type="text" id="mbn" required="required"  onChange="return phone()" placeholder="building name">
                </label>
            </div>

			<div class="form-row">
                <label>
                    <span>Email Id </span><input name="mem" type="email" id="mem" required="required"  onChange="return phone()" placeholder="Email ID">
                </label>
            </div>
			
			
			<div class="form-row">
                <label>
                    <span>Username </span>
                    <input name="un" type="text" id="un" required="required" onChange="return phone()" placeholder="Username">
                </label>
            </div>
			
            <div class="form-row">
                <label>
                    <span>Password </span><input name="pass" type="password" id="pass" required="required" onChange="return phone()" placeholder="Password">
                </label>
            </div>


            <div class="form-row">
                <button name="send" type="submit" onclick="gotonextpage()" id="send" value="Send">Submit Form</button>
            </div>

        </form>

    </div>
</body>

</html>
