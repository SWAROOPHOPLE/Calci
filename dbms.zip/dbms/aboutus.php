<?php
error_reporting(1);

?><!DOCTYPE html>
<html lang="en">
<head>
  <title>Society Management</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <style>
  .carousel-inner > .item > img,
  .carousel-inner > .item > a > img {
      width: 100%;
      margin: auto;
	  }
	  
.bg-4 { 
      background-color: #2f2f2f; /* Black Gray */
      color: #fff;
	   padding-top: 70px;
      padding-bottom: 70px;
  }
	  
	  
  </style>
 </head>
<body>
  </br>
<div align="center"> <img src="logo1.png" alt="LOGO" width="500" height="100">
</div>
	 <div class="modal fade" id="signupModal" role="dialog">
    <div class="modal-dialog">
    
    
      <div class="modal-content">
        <div class="modal-header" style="padding:35px 50px;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4><span class="glyphicon glyphicon-road"></span> Sign Up</h4>
        </div>
        <div class="modal-body" style="padding:40px 50px;">
            
              <a href="society.php"><button type="button" class="btn btn-success btn-block"><span class="glyphicon glyphicon-home"></span><h4> Society</h4></button></a>
			  <br/>
			  <h5 align="center">or</h5><br/>
              <a href="service_provider.php"><button type="button" class="btn btn-success btn-block"><span class="glyphicon glyphicon-user"></span><h4> Service Provider</h4></button></a>
          
        </div>
             </div>
      
    </div>
  </div> 
	<div class="container">
	  
  <br/>
	  <hr/>
 <ul class="nav nav-pills">
  
 
    <li><a  href="index.php"><h3>Home</h3></a></li>
		<li ><a href="services.php"><h3>Services</h3></a></li>
	
 <?php
 	session_start();
$id=$_SESSION['eid'];
    if($id!="")
	{echo"<li><a href='?log=out'><h3>My Profile</h3></a></li>";
		echo"<button type='button' class= 'btn pull-right btn-success btn-lg'><a href='?log=out'><font color='white'>Logout</font></a></button>";}
   else {echo"<li><a href='loginmyp.php'><h3>My Profile</h3></a></li>";
	    echo"<button type='button' class='btn pull-right btn-primary btn-lg' id='signupBtn'>Sign Up</button> 
	  <button type='button' class= 'btn pull-right btn-success btn-lg'><a href='loginmyp.php'><font color='white'>Login</font></a></button>";
	   
	   
   }
   
   if(isset($_REQUEST['log'])=='out')
{
session_destroy();
header("location:loginmyp.php");
}

   ?>
<li class="active"><a href="aboutus.php"><h3>About Us</h3></a></li>
		<br/>
		 </ul></br>
  <hr/><br/>
<div class="container">
<img src="pic5.jpg" alt="aboutus" style="width:1122px;height:398px;">
<p><h3>Society Services is the product of Convivial Software, with Offices in Mumbai.</h2></p>
<p>Society Services is a web-based Housing Society Management solution for residential, commercial and  Housing Societies.<br/>
   To be launched in April 2016, SocietyServices.com has placed its firm steps in the society management industry and won hearts of a lot of<br/>
   happy customers.
</p>   

<p>We are Ace in giving successful and comprehensive services to Co-operative Housing Societies.We are the Experts in Computerized<br/>
   Billing & Accounts Services to Housing Societies Services. With the changing Ages in Housing Societies management, we have Simplified the call for Housing<br/>
   Societies Services.
</p>   
</div>

<div class="container">
  <h2>Society Services</h2>
  <p>The auto updating progress-bar represents our excellence </p> 
  <div class="progress">
    <div class="progress-bar progress-bar-success progress-bar-striped" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width:75%">
      75% Complete (Hardware)
    </div>
  </div>
  <div class="progress">
    <div class="progress-bar progress-bar-info progress-bar-striped" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:80%">
      80% Complete (General Maintainance)
    </div>
  </div>
  <div class="progress">
    <div class="progress-bar progress-bar-warning progress-bar-striped" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width:60%">
      60% Complete (Security)
    </div>
  </div>
  <div class="progress">
    <div class="progress-bar progress-bar-danger progress-bar-striped" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:70%">
      70% Complete (Pest Control)
    </div>
  </div>
</div>



  <script>
$(document).ready(function(){
    $("#signupBtn").click(function(){
        $("#signupModal").modal();
    });
});
</script>
</body>
</html>