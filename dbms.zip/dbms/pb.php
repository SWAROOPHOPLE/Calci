<?php
error_reporting(1);

?>
<?php
require 'connect.php';
$bd=$_REQUEST['itemno'];
if(isset($_REQUEST['send']))
{

$name=$_REQUEST['sp_name'];

$de=$_REQUEST['bk_dt_execution'];
$cnf=$_REQUEST['bk_confirmation'];

$sql = "select * from booking,service_provider where booking.society_username='$bd' and booking.sp_id=service_provider.sp_id";
if ($con->query($sql)) 
{
    
 //echo $c.$f.$a;
} else 
{
	echo (mysql_error($con));

	}
}
$con->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Society Management</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <style>
  
  </style>
    <style>

table {
    border-collapse: collapse;
    width: 100%;
	margin:2;
}

th, td {
    text-align: center;
    padding: 13px;
}



th {
    background-color:#3f3f3f;
    color: white;
}
</style>
    <style>
	
     
    </style>
	<style>
.center {
    margin: auto;
    width: 60%;
    padding: 100px;
}

     
	   .a{
    opacity: 0.7;
    filter: alpha(opacity=50); 
	}
	.ascroll{
		max-height:605px;
		overflow-y:scroll;
	}
	.bscroll{
		max-height:600px;
		overflow-y:scroll;
	}
</style>
</head>
<body >
	
</br>
<div align="center"> <img src="logo1.png" alt="LOGO" width="500" height="100">
</div>
	
	<div class="container">
	  
  <br/>
	  <hr/>
 <ul class="nav nav-pills">
  
 
    <li><a  href="index.php"><h3>Home</h3></a></li>
		<li ><a href="services.php"><h3>Services</h3></a></li>
		
		<li class="active"><?php echo"<a href='profile.php?itemno=$bd'><h3>My Profile</h3></a>"?></li>
		<li><a href="aboutus.php"><h3>About Us</h3></a></li>
		<br/>
		 <?php
 	session_start();
$id=$_SESSION['eid'];
    if($id!="")
   echo"<button type='button' class= 'btn pull-right btn-success btn-lg'><a href='?log=out'><font color='white'>Logout</font></a></button>";
   if(isset($_REQUEST['log'])=='out')
{
session_destroy();
header("location:loginmyp.php");
}
   ?>
  </ul></br>
  <hr/><br/>
  
	<div align="center"> 
	 <div class="btn-group" >
    <button type="button" class="btn btn-primary"><?php echo"<a href='pin.php?itemno=$bd'>"?><font color="white">Personal Information</font></a></button>

    <button type="button" class="btn btn-primary"><?php echo"<a href='pb.php?itemno=$bd'>"?><font color="white">Pending Bookings </font></a></button>
 <button type="button" class="btn btn-primary"><?php echo"<a href='cb.php?itemno=$bd'>"?><font color="white">Confirmed Bookings</font></a></button>

  </div></div>
</br>
	<?php
require 'connect.php';
$bd=$_REQUEST['itemno'];

$sql = "select * from booking,service_provider where booking.society_username='$bd' and booking.sp_id=service_provider.sp_id";
 $row = $con->query($sql);
  echo "<table align='center'><tr> <th>Name of service</th><th>Date of Exceution</th>";

   while($arr = $row->fetch_assoc()) 
   {
$name=$arr['sp_name'];
$cnf=$arr['bk_confirmation'];
$de=$arr['bk_dt_execution'];
if($cnf==0)
echo "<tr><td>" .$name."</td><td>" . $de."</td></tr>";
        }
          echo "</table>";


   	?>
	 	
	  
	  <br/>
   
	
	
	  </div>
  <script>
$(document).ready(function(){
    $("#signupBtn").click(function(){
        $("#signupModal").modal();
    });
});
</script>
</body>
</html>	  
	  