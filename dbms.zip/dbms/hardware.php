<?php
require 'connect.php';
$spid=$_REQUEST['spid'];
$spii=$_REQUEST['spii'];
if(isset($_REQUEST['send']))
{

$from=$_REQUEST['from'];
$to=$_REQUEST['to'];
$plu=$_REQUEST['plu'];
$ele=$_REQUEST['ele'];
$wood=$_REQUEST['wood'];
$glass=$_REQUEST['glass'];
$mas=$_REQUEST['mas'];
$pai=$_REQUEST['pai'];

$sql = "INSERT INTO hardware(start_time,end_time,hd_plumbing,hd_electric_work,hd_wood_work,hd_glass_work,hd_masonary,hd_painters,sp_id,hd_category_id)
									 VALUES
									 ('$from','$to','$plu','$ele','$wood','$glass','$mas','$pai','$spid','2')";
if ($con->query($sql)) 
{
    
 //echo $c.$f.$a;
} else 
{
	echo (mysql_error($con));

	}
	
	header("location:new3.php");
}
$con->close();
?>
<html>

<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	
	<link rel="stylesheet" href="form-basic.css">
	 <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<style>
.main-content{
	background:url(back.jpg);
	background-size: cover;
    background-repeat: no-repeat;
}
</style>

<body>
</br>
<div align="center"> <img src="logo1.png" alt="LOGO" width="500" height="100">
</div>
   <div class="modal fade" id="signupModal" role="dialog">
    <div class="modal-dialog">
    
    
      <div class="modal-content">
        <div class="modal-header" style="padding:35px 50px;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4><span class="glyphicon glyphicon-road"></span> Sign Up</h4>
		  
        </div>
        <div class="modal-body" style="padding:40px 50px;">
            
              <a href="society.php"><button type="button" class="btn btn-success btn-block"><span class="glyphicon glyphicon-home"></span><h4> Society</h4></button></a>
			  <br/>
			  <h5 align="center">or</h5><br/>
              <a href="service_provider.php"><button type="button" class="btn btn-success btn-block"><span class="glyphicon glyphicon-user"></span><h4> Service Provider</h4></button></a>
          
        </div>
             </div>
      
    </div>
  </div> 



<div class="container">
 
	  
  <br/>
	  <hr/>
 <ul class="nav nav-pills">
  
 
    <li ><a  href="index.php"><h3>Home</h3></a></li>
		<li ><a href="services.php"><h3>Services</h3></a></li>
		
		<li><a href="loginmyp.php"><h3>My Profile</h3></a></li>
		<li><a href="aboutus.php"><h3>About Us</h3></a></li>
		<br/>
		 <button type="button" class="btn pull-right btn-primary btn-lg" id="signupBtn">Sign Up</button> 
		 
	  <button type="button" class= "btn pull-right btn-success btn-lg"><a href="loginmyp.php"><font color="white">Login</font></a></button>
  </ul>
  <hr/><br/>
  </div>
  <div class="modal fade" id="signupModal" role="dialog">
    <div class="modal-dialog">
    
    
      <div class="modal-content">
        <div class="modal-header" style="padding:35px 50px;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4><span class="glyphicon glyphicon-road"></span> Sign Up</h4>
        </div>
        <div class="modal-body" style="padding:40px 50px;">
            
              <a href="society.php"><button type="button" class="btn btn-success btn-block"><span class="glyphicon glyphicon-home"></span><h4> Society</h4></button></a>
			  <br/>
			  <h5 align="center">or</h5><br/>
              <a href="service_provider.php"><button type="button" class="btn btn-success btn-block"><span class="glyphicon glyphicon-user"></span><h4> Service Provider</h4></button></a>
          
        </div>
             </div>
      
    </div>
  </div>
    <div class="main-content"> <br/> <br/>


        <form method="post" name="f1" onSubmit="return vali()" class="form-basic" action="">

		            <div class="form-title-row">
                <h3>Hardware Services</h3>
            </div>

            <div class="form-row">
                <label>
                    Hours Of Operation </br>
                    <span> From </span><input name="from" type="text" id="from" required="required"  onChange="return phone()" placeholder="HH:MM"><br/>
					<br/><span> To </span><input name="to" type="text" id="to" required="required"  onChange="return phone()" placeholder="HH:MM">
                </label>
            </div>

			<div class="form-row">
                <label>
                    <span>Plumbing </span><br/>
                   <span> </span> <input type="radio" name="plu" required="required" onChange="return phone()" value="yes"> YES </input>
                   <span> </span><input type="radio" name="plu" required="required" onChange="return phone()" value="no">NO </input>
                </label>
            </div>
			
			
			<div class="form-row">
                <label>
                    <span>Electric Works </span><br/>
                   <span> </span> <input type="radio" name="ele" required="required" onChange="return phone()" value="yes"> YES </input>
                   <span> </span><input type="radio" name="ele" required="required" onChange="return phone()" value="no">NO </input>
                </label>
            </div>
			
			
			<div class="form-row">
                <label>
                    <span>Wood Works </span><br/>
                   <span> </span> <input type="radio" name="wood" required="required" onChange="return phone()" value="yes"> YES </input>
                   <span> </span><input type="radio" name="wood"required="required" onChange="return phone()"  value="no">NO </input>
                </label>
            </div>
			
			
			<div class="form-row">
                <label>
                    <span>Glass Works </span><br/>
                   <span> </span> <input type="radio" name="glass" required="required" onChange="return phone()" value="yes"> YES </input></td>
                   <span> </span><input type="radio" name="glass" required="required" onChange="return phone()" value="no">NO </input>
                </label>
            </div>
			
			<div class="form-row">
                <label>
                    <span>Masonary </span><br/>
                   <span> </span> <input type="radio" name="mas" required="required" onChange="return phone()" value="yes"> YES </input>
                   <span> </span><input type="radio" name="mas" required="required" onChange="return phone()" value="no">NO </input>
                </label>
            </div>
			
			
			<div class="form-row">
                <label>
                    <span>Painters </span><br/>
                   <span> </span> <input type="radio" name="pai" required="required" onChange="return phone()" value="yes"> YES </input>
                   <span> </span><input type="radio" name="pai" required="required" onChange="return phone()" value="no">NO </input>
                </label>
            </div>
			
			
			
			
			
            <div class="form-row">
                <button name="send" type="submit" id="send" onclick="gotonextpage()" value="Send">Submit Form</button>
            </div>

        </form>

    </div>

<script>

$(document).ready(function(){
    $("#signupBtn").click(function(){
        $("#signupModal").modal();
    });
});
</script>
</body>

</html>
