<?php
error_reporting(1);

?><?php
$id=$_REQUEST['itemno'];
$itemn=$_REQUEST['usrm'];
include("config.php");
$itemno=$_REQUEST['itemno'];
if(isset($_REQUEST['send']))
  {
	 $mn=$_REQUEST['mn'];
$ban=$_REQUEST['ban'];	 
	   $orderno='so'.rand(1,9999);
	   $sql=mysql_query("insert into booking (society_username,sp_id,bk_dt_execution,bk_confirmation,bk_rating,orderno)
	   values('$itemn','$id','$mn','0','$ban','$orderno')");
	if($sql==false)
	{
		die(mysql_error());
	}
	header("location:new2.php");
  }
if(isset($_REQUEST['log'])=='out')
{
session_destroy();
header("location:index.php");
}
else if($id=="")
{
header("location:index.php");
}
if($itemno=="")
{
header("location:index.php");
}
	
?>
<html>
<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	
	<link rel="stylesheet" href="form-basic.css">
	 <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
 <style>
 .bg-4 { 
      background-color: #2f2f2f; /* Black Gray */
      color: #fff;
	   padding-top: 70px;
      padding-bottom: 70px;
  }</style> 
</head>

<body>
<?php
require 'connect.php';
$bd=$_REQUEST['itemno'];
$bde=$_REQUEST['usrm'];
$sql = "select * from service_provider where sp_id='$bd'";
   $row = $con->query($sql);
   while($arr = $row->fetch_assoc()) 
        {
			$name=$arr['sp_name'];

$ph=$arr['sp_phone_no'];

$area=$arr['sp_area'];
$str=$arr['sp_street'];
$ct=$arr['sp_city'];
$cm=$arr['sp_common_email'];
$add=$str." ".$area." ".$ct;

		}

	
	?>
  
<br/>

<div align="center"> <img src="logo12.png" alt="LOGO" width="500" height="100">
</div>
 <div class="container">
	  
  <br/>
	  <hr/>
 <ul class="nav nav-pills">
  
 
    <li><a  href="homepage.html"><h3>Home</h3></a></li>
		<li class="active"><a href="services.php"><h3>Services</h3></a></li>
		<li><?php echo "<a href='profile.php?itemno=$itemn'>"?><h3>My Profile</h3></a></li>
		<li><a href="aboutus.html"><h3>About Us</h3></a></li>
		<br/>
  </ul>
  <hr/><br/></div>
<br/>


<div class="container">




<div align="center">
   <h3><li style="list-style-type:NONE"><a href="inventory.php">INVENTORY</a></li></h3>
</div>
<br/>
    <div class="main-content">


        <form method="POST" class="form-basic" action="#">

            <div class="form-title-row">
                <h3>UPDATE INVENTORY</h3>
            </div>

            <div class="form-row">
                <label>
                    <span>ID:</span>
          <input type="text" name="ID"></label>
		   </div>

			<div class="form-row">
                <label>
                    <span>Food Name:</span>
       <input type="text" name="foodname">
	   </label>
            </div>
			
			 <div class="form-row">
                <label>
                    <span>Quantity:</span>
<input type="text" name="quantity">
			   </label>
            </div>
			
			<div class="form-row">
                <label>
                    <span>Amount:</span>
<input type="text" name="amount">
			   </label>
            </div>
			
			<div class="form-row">
                <label>
                    <span>Day:</span>
          <input type="text" name="day"></label>
		   </div>
		   
		   
		   <div class="form-row">
                <label>
                    <span>Month:</span>
          <input type="text" name="month"></label>
		   </div>
		   
		   
		   <div class="form-row">
                <label>
                    <span>Year:</span>
          <input type="text" name="year"></label>
		   </div>
		   
		   
		
            <div class="form-row">
                <button name="submit" type="submit" id="submit" value="submit">Submit </button>
            </div>

        </form>

    </div>
	
	</div>
	
<br/><br/><br/>
</body>

</html>
