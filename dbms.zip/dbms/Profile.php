<?php
error_reporting(1);

?>

<?php
require 'connect.php';
$bd=$_REQUEST['itemno'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Society Management</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <style>
  
  </style>
</head>
<body >
</br>
<div align="center"> <img src="logo1.png" alt="LOGO" width="500" height="100">
</div>
	 
	<div class="container">
	  
  <br/>
	  <hr/>
 <ul class="nav nav-pills">
  
 
    <li><a  href="index.php"><h3>Home</h3></a></li>
		<li ><a href="services.php"><h3>Services</h3></a></li>
		
		<li class="active"><?php echo"<a href='profile.php?itemno=$bd'><h3>My Profile</h3></a>"?></li>
		<li><a href="aboutus.php"><h3>About Us</h3></a></li>
		<br/>
		
		 <?php
 	session_start();
$id=$_SESSION['eid'];
    if($id!="")
   echo"<button type='button' class= 'btn pull-right btn-success btn-lg'><a href='?log=out'><font color='white'>Logout</font></a></button>";
   if(isset($_REQUEST['log'])=='out')
{
session_destroy();
header("location:loginmyp.php");
}
   ?>
  </ul></br>
  <hr/><br/>
	<div align="center"> 
	 <div class="btn-group" >
    <button type="button" class="btn btn-primary"><?php echo"<a href='pin.php?itemno=$bd'>"?><font color="white">Personal Information</font></a></button>

    <button type="button" class="btn btn-primary"><?php echo"<a href='pb.php?itemno=$bd'>"?><font color="white">Pending Bookings </font></a></button>
 <button type="button" class="btn btn-primary"><?php echo"<a href='cb.php?itemno=$bd'>"?><font color="white">Confirmed Bookings</font></a></button>

  </div></div>
	  </div>
  <script>
$(document).ready(function(){
    $("#signupBtn").click(function(){
        $("#signupModal").modal();
    });
});
</script>
</body>
</html>	  
	  