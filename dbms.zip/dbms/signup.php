<?php
require 'connect.php';
$c=$_GET['company_name'];
$f=$_GET['mf_name'];
$l=$_GET['ml_name'];
$a=$_GET['sp_area'];
$s=$_GET['sp_street'];
$ci=$_GET['sp_city'];
$p=$_GET['sp_pincode'];
$ph=$_GET['sp_phone_no'];
$e=$_GET['sp_common_email'];
$cat=$_GET['category_id'];
$w=$_GET['sp_website'];
$u=$_GET['sp_username'];
$pass=$_GET['sp_password'];
$cpass=$_GET['sp_password1'];
$sql = "INSERT INTO service_provider(sp_name,sp_phone_no,sp_mf_name,sp_ml_name,sp_area,sp_street,sp_city,sp_common_email,
                                     sp_category_id,sp_website,sp_username,sp_pincode,sp_password)
									 VALUES
									 ('$c','$ph','$f','$l','$a','$s','$ci','$e','$cat','$w','$u','$p','$pass')";
if ($con->query($sql)) 
{
    
	header('Location: message.html');
} else 
{
	echo (mysql_error($con));

	}
$con->close();
?>