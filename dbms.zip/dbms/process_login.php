<?php
if(isset($_POST["log"]))
{
$a=$_POST["usrname"];
$b=$_POST["psw"];




$servername='localhost';
$username='root';
$password='';
$dbname='dbms';
// Create connection
$con = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}
$c="select * from registration where username='$a' and password='$b'";
$res=mysqli_query($con,$c);

$row=mysqli_fetch_row($res);

	ECHO"THANKS FOR LOGIN<BR>";

	echo "USERNAME IS :$row[0]<BR>";
	echo "PASSWORD IS :$row[1]";


mysqli_close($con);



}
?>