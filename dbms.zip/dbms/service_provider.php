<?php
require 'connect.php';
if(isset($_REQUEST['send']))
{

$cn=$_REQUEST['cn'];
$mf=$_REQUEST['mf'];
$ml=$_REQUEST['ml'];
$a=$_REQUEST['a'];
$s=$_REQUEST['s'];
$c=$_REQUEST['c'];
$pn=$_REQUEST['pn'];
$em=$_REQUEST['em'];
$un=$_REQUEST['un'];
$pass=$_REQUEST['pass'];
$pc=$_REQUEST['pc'];
$cat=$_REQUEST['cat'];
$sp_id=rand(1,9999);
$sql = "INSERT INTO service_provider(sp_id,sp_name,sp_phone_no,sp_mf_name,sp_ml_name,sp_area,sp_street,sp_city,sp_common_email,sp_category_id,sp_username,sp_pincode)
									 VALUES
									 ('$sp_id','$cn','$pn','$mf','$ml','$a','$s','$c','$em','$cat','$un','$pc')";
									 
			 
									 
if ($con->query($sql)) 
{
    
//////// echo $c.$f.$a;
} else 
{
	echo (mysql_error($con));

	}
	
$sql1 = "INSERT INTO  registration(username,password,type)
									 VALUES
									 ('$un','$pass','2')";
									 
if ($con->query($sql1)) 
{
    
//////// echo $c.$f.$a;
} else 
{
	echo (mysql_error($con));

	}

									
  $scl="select * from service_provider";
    $rowb = $con->query($scl);
	 while($arb = $rowb->fetch_assoc()) 
	 {
		 $bk=$arb['sp_id'];
	 }
              
	if($cat==1)
		header("location:General_maintainance.php?spid=$sp_id");
	else if($cat==2)
			header("location:hardware.php?spid=$sp_id&spii=$bk");
		else if($cat==3)
			header("location:pest_control.php?spid=$sp_id");
		else if($cat==4)
			header("location:security.php?spid=$sp_id");
}
$con->close();
?>


<html>

<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	
	<link rel="stylesheet" href="form-basic.css">
	 <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<style>
.main-content{
	background:url(back.jpg);
	background-size: cover;
    background-repeat: no-repeat;
}
</style>

<body>
</br>
<div align="center"> <img src="logo1.png" alt="LOGO" width="500" height="100">
</div>
<div class="container">
 
	  
  <br/>
	  <hr/>
 <ul class="nav nav-pills">
  
 
    <li><a  href="index.php"><h3>Home</h3></a></li>
		<li><a href="services.php"><h3>Services</h3></a></li>
		
		<li><a href="loginmyp.php"><h3>My Profile</h3></a></li>
		<li><a href="aboutus.php"><h3>About Us</h3></a></li>
		<br/>
	  <button type="button" class= "btn pull-right btn-success btn-lg" ><a href="loginmyp.php"><font color="white">Login</font></a></button>
  </ul>
  <hr/><br/>
  </div>
    <div class="main-content">
     
</br></br>
        <form method="post" name="f1" onSubmit="return vali()" class="form-basic" >

            <div class="form-title-row">
                <h3>Service Provider Signup Form </h3>
            </div>

            <div class="form-row">
                <label>
                    <span>Company Name </span>
                    <input name="cn" type="text" id="cn" required="required" onChange="return phone()" placeholder="company name"><br/>
					
                </label>
            </div>

			<div class="form-row">
                <label>
                    <span>Manager </span>
					<input name="mf" type="text" id="mf" required="required"  onChange="return phone()" placeholder="firstname"><br/><br/>
					<span> </span><input name="ml" type="text" id="ml" required="required"  onChange="return phone()" placeholder="lastname">
					</label>
            </div>
			
			 <div class="form-row">
                <label>
                    <span>Address </span>
                    <input name="a" type="text" id="a" required="required" onChange="return phone()" placeholder="Area"><br/><br/>
					<span> </span><input name="s" type="text" id="s" required="required"  onChange="return phone()" placeholder="Street"><br/><br/>
					<span> </span><input name="c" type="text" id="c" required="required"  onChange="return phone()" placeholder="City"> <br/> 
                </label>
            </div>
			
			<div class="form-row">
                <label>
                    <span>Pincode:</span>
                     <input name="pc" type="text" id="pc" required="required"  onChange="return phone()" placeholder="Pincode">
                </label>
            </div>
			
             <div class="form-row">
                <label>
                    <span>Phone No </span>
                    <input name="pn" type="text" id="pn" required="required" onChange="return phone()" placeholder="Phone Number">
                </label>
            </div>
			
			<div class="form-row">
                <label>
                    <span>Email Id </span>
                    <input name="em" type="email" id="em" required="required"  onChange="return phone()" placeholder="Email ID">
                </label>
            </div>
			<div id="cat">
			<div class="form-row">
                <label>
                    <span>Catagory </span><br/>
                   <span> </span> <input type="radio" name="cat" value="4" id="sec">Security</input><br/>
                   <span> </span> <input type="radio" name="cat" value="3" id="pes">Pest Control</input><br/>
                   <span> </span> <input type="radio" name="cat" value="1" id="gen">General Maintainance</input><br/>
                   <span> </span> <input type="radio" name="cat" value="2" id="har">Hardware</input><br/>
                </label>
            </div>
			</div>
			
			
			<div class="form-row">
                <label>
                    <span>Username </span>
                    <input name="un" type="text" id="un" required="required" onChange="return phone()" placeholder="Username">
                </label>
            </div>
			
            <div class="form-row">
                <label>
                    <span>Password </span>
                    <input name="pass" type="password" id="pass" required="required" onChange="return phone()" placeholder="Password">
                </label>
            </div>


            <div class="form-row">
                <button name="send" type="submit" onclick="gotonextpage()" id="send" value="Send">NEXT </button>
            </div>

        </form>

    </div>

</body>

</html>






